import bpy
import os
import glob
import re
from collections import OrderedDict
import shutil

from ..common.global_config import GlobalConfig
from ..common.logic_name import LogicName
from .node_postprocess_base import SSMTNode_PostProcess_Base

_name_mapping_cache = {}
_reverse_name_mapping_cache = {}
# 资源缓存按“材质内容签名”去重，避免同一套贴图被重复复制/重复生成 Resource。
_material_resource_cache = {}


def clear_name_mapping_cache():
    global _name_mapping_cache, _reverse_name_mapping_cache, _material_resource_cache
    _name_mapping_cache.clear()
    _reverse_name_mapping_cache.clear()
    _material_resource_cache.clear()


class MaterialPrefixItem(bpy.types.PropertyGroup):
    prefix: bpy.props.StringProperty(
        name="前缀",
        description="材质名称前缀，用于筛选检测的材质",
        default=""
    )


class DetectedMaterialItem(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="物体名称", default="")
    missing_prefix: bpy.props.StringProperty(name="缺失前缀", default="")


MATERIAL_DETECT_PRESETS = [
    "DiffuseMap",
    "NormalMap",
    "LightMap",
    "MaterialMap",
    "RampMap",
    "HighLightMap",
    "StockingMap",
]


class SSMT_OT_MaterialDetectAddPrefix(bpy.types.Operator):
    bl_idname = "ssmt.material_detect_add_prefix"
    bl_label = "添加前缀"
    bl_description = "按预设顺序添加下一个材质检测前缀"
    bl_options = {'INTERNAL'}

    node_name: bpy.props.StringProperty()

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
            return {'CANCELLED'}
        node = tree.nodes.get(self.node_name)
        if not node or node.bl_idname != 'SSMTNode_PostProcess_Material':
            return {'CANCELLED'}

        existing = {item.prefix for item in node.material_detect_prefixes}
        for preset in MATERIAL_DETECT_PRESETS:
            if preset not in existing:
                new_item = node.material_detect_prefixes.add()
                new_item.prefix = preset
                return {'FINISHED'}

        self.report({'WARNING'}, "所有预设前缀已添加")
        return {'CANCELLED'}


class SSMT_OT_MaterialDetectRemovePrefix(bpy.types.Operator):
    bl_idname = "ssmt.material_detect_remove_prefix"
    bl_label = "移除前缀"
    bl_description = "移除指定索引的材质检测前缀"
    bl_options = {'INTERNAL'}

    node_name: bpy.props.StringProperty()
    item_index: bpy.props.IntProperty()

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
            return {'CANCELLED'}
        node = tree.nodes.get(self.node_name)
        if node and node.bl_idname == 'SSMTNode_PostProcess_Material':
            if 0 <= self.item_index < len(node.material_detect_prefixes):
                node.material_detect_prefixes.remove(self.item_index)
        return {'FINISHED'}


class SSMT_OT_MaterialDetectAddCustomPrefix(bpy.types.Operator):
    bl_idname = "ssmt.material_detect_add_custom_prefix"
    bl_label = "添加自定义前缀"
    bl_description = "添加手动输入的材质检测前缀"
    bl_options = {'INTERNAL'}

    node_name: bpy.props.StringProperty()

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
            return {'CANCELLED'}
        node = tree.nodes.get(self.node_name)
        if not node or node.bl_idname != 'SSMTNode_PostProcess_Material':
            return {'CANCELLED'}

        custom = node.temp_prefix_input.strip()
        if not custom:
            self.report({'WARNING'}, "请输入前缀")
            return {'CANCELLED'}

        existing = {item.prefix for item in node.material_detect_prefixes}
        if custom in existing:
            self.report({'WARNING'}, f"前缀 '{custom}' 已存在")
            return {'CANCELLED'}

        new_item = node.material_detect_prefixes.add()
        new_item.prefix = custom
        node.temp_prefix_input = ""
        return {'FINISHED'}


class SSMT_OT_MaterialDetect(bpy.types.Operator):
    bl_idname = "ssmt.material_detect"
    bl_label = "Material Detect"
    bl_description = "Detect missing prefixed materials from connected objects, including nested blueprints"
    bl_options = {'INTERNAL'}

    node_name: bpy.props.StringProperty()

    @staticmethod
    def _is_result_output_node(node) -> bool:
        return getattr(node, "bl_idname", "") in {
            "SSMTNode_Result_Output",
            "SSMTNode_Result_Output_NTMIModImp",
        }

    def _find_result_output(self, node, visited=None):
        if visited is None:
            visited = set()
        tree_name = node.id_data.name if hasattr(node, 'id_data') and node.id_data else ""
        node_key = f"{tree_name}::{node.name}"
        if node_key in visited:
            return None
        visited.add(node_key)

        if self._is_result_output_node(node):
            return node

        for input_socket in node.inputs:
            if input_socket.bl_idname == 'SSMTSocketPostProcess' and input_socket.is_linked:
                for link in input_socket.links:
                    result = self._find_result_output(link.from_node, visited)
                    if result:
                        return result
        return None

    def _collect_object_info_nodes(self, node, visited=None, visited_trees=None):
        if visited is None:
            visited = set()
        if visited_trees is None:
            visited_trees = set()

        tree_name = node.id_data.name if hasattr(node, 'id_data') and node.id_data else ""
        node_key = f"{tree_name}::{node.name}"
        if node_key in visited:
            return []
        visited.add(node_key)

        detect_nodes = []
        if node.bl_idname in {'SSMTNode_Object_Info', 'SSMTNode_MultiFile_Export'}:
            detect_nodes.append(node)

        if node.bl_idname == 'SSMTNode_Blueprint_Nest':
            nested_tree_name = str(getattr(node, 'blueprint_name', '') or '').strip()
            if nested_tree_name and nested_tree_name != 'NONE' and nested_tree_name not in visited_trees:
                nested_tree = bpy.data.node_groups.get(nested_tree_name)
                if nested_tree and getattr(nested_tree, 'bl_idname', '') == 'SSMTBlueprintTreeType':
                    visited_trees.add(nested_tree_name)
                    for nested_node in nested_tree.nodes:
                        if self._is_result_output_node(nested_node):
                            detect_nodes.extend(
                                self._collect_object_info_nodes(
                                    nested_node,
                                    visited=visited,
                                    visited_trees=visited_trees,
                                )
                            )

        for input_socket in node.inputs:
            if input_socket.is_linked:
                for link in input_socket.links:
                    detect_nodes.extend(
                        self._collect_object_info_nodes(
                            link.from_node,
                            visited=visited,
                            visited_trees=visited_trees,
                        )
                    )
        return detect_nodes

    def _iter_detect_object_names(self, detect_nodes):
        for detect_node in detect_nodes:
            node_type = getattr(detect_node, 'bl_idname', '')
            if node_type == 'SSMTNode_Object_Info':
                obj_name = getattr(detect_node, 'object_name', '')
                if obj_name:
                    yield obj_name
            elif node_type == 'SSMTNode_MultiFile_Export':
                for item in getattr(detect_node, 'object_list', []):
                    obj_name = getattr(item, 'object_name', '')
                    if obj_name:
                        yield obj_name

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
            self.report({'WARNING'}, 'No active blueprint tree')
            return {'CANCELLED'}

        node = tree.nodes.get(self.node_name)
        if not node or node.bl_idname != 'SSMTNode_PostProcess_Material':
            return {'CANCELLED'}

        prefixes = [item.prefix.strip() for item in node.material_detect_prefixes if item.prefix.strip()]
        if not prefixes:
            self.report({'WARNING'}, 'Add at least one material prefix first')
            return {'CANCELLED'}

        result_output = self._find_result_output(node)
        if not result_output:
            self.report({'WARNING'}, 'No connected Result_Output node found')
            return {'CANCELLED'}

        detect_nodes = self._collect_object_info_nodes(result_output)
        if not detect_nodes:
            self.report({'WARNING'}, 'No connected object nodes found')
            return {'CANCELLED'}

        node.detected_materials.clear()

        unique_object_names = []
        seen_object_names = set()
        for obj_name in self._iter_detect_object_names(detect_nodes):
            if obj_name in seen_object_names:
                continue
            seen_object_names.add(obj_name)
            unique_object_names.append(obj_name)

        missing_count = 0
        for obj_name in unique_object_names:
            obj = bpy.data.objects.get(obj_name)
            if not obj:
                continue

            for prefix in prefixes:
                has_prefix_material = False
                for material_slot in obj.material_slots:
                    material = material_slot.material
                    if material and material.name.startswith(prefix):
                        has_prefix_material = True
                        break

                if has_prefix_material:
                    continue

                item = node.detected_materials.add()
                item.object_name = obj_name
                item.missing_prefix = prefix
                missing_count += 1

        node.detect_all_ok = (missing_count == 0)

        if missing_count > 0:
            self.report({'WARNING'}, f'Detection finished: {missing_count} missing entries across {len(unique_object_names)} objects')
        else:
            self.report({'INFO'}, f'Detection finished: all prefixes found across {len(unique_object_names)} objects')
        return {'FINISHED'}


class SSMT_OT_MaterialDetectClear(bpy.types.Operator):
    bl_idname = "ssmt.material_detect_clear"
    bl_label = "清除结果"
    bl_description = "清除检测结果"
    bl_options = {'INTERNAL'}

    node_name: bpy.props.StringProperty()

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
            return {'CANCELLED'}
        node = tree.nodes.get(self.node_name)
        if node and node.bl_idname == 'SSMTNode_PostProcess_Material':
            node.detected_materials.clear()
            node.detect_all_ok = False
        return {'FINISHED'}


class SSMTNode_PostProcess_Material(SSMTNode_PostProcess_Base):
    bl_idname = 'SSMTNode_PostProcess_Material'
    bl_label = '材质转资源'
    bl_description = '根据场景物体的材质和纹理创建资源引用'

    @staticmethod
    def clear_cache():
        clear_name_mapping_cache()

    material_to_resource_override: bpy.props.BoolProperty(
        name="覆盖现有资源",
        description="如果资源已存在，则覆盖它",
        default=False
    )
    material_switch_var: bpy.props.StringProperty(
        name="材质切换变量",
        description="用于材质切换的起始变量名(会自动递增)",
        default="$swapkey150",
        update=lambda self, context: self.update_node_width([self.material_switch_var])
    )
    material_detect_prefixes: bpy.props.CollectionProperty(type=MaterialPrefixItem)
    temp_prefix_input: bpy.props.StringProperty(name="自定义前缀", default="")
    detected_materials: bpy.props.CollectionProperty(type=DetectedMaterialItem)
    detect_all_ok: bpy.props.BoolProperty(name="全部正确", default=False)
    show_detect_panel: bpy.props.BoolProperty(
        name="材质检测",
        description="展开/收起材质检测面板",
        default=False
    )

    _ntmi_modimp_extra_ps_t2_diffuse_map = False

    def apply_name_mapping(self, mapping):
        global _name_mapping_cache, _reverse_name_mapping_cache

        node_key = self.name
        _name_mapping_cache[node_key] = mapping.copy()
        _reverse_name_mapping_cache[node_key] = {}

        for original_name, new_name in mapping.items():
            _reverse_name_mapping_cache[node_key][new_name] = original_name

        print(f"[MaterialToResource] 已应用名称映射: {len(mapping)} 条规则")
        for original_name, new_name in mapping.items():
            print(f"  映射: '{original_name}' -> '{new_name}'")

    def _get_name_mapping(self):
        global _name_mapping_cache
        return _name_mapping_cache.get(self.name, {})

    def _get_reverse_name_mapping(self):
        global _reverse_name_mapping_cache
        return _reverse_name_mapping_cache.get(self.name, {})

    def draw_buttons(self, context, layout):
        layout.prop(self, "material_to_resource_override")
        layout.prop(self, "material_switch_var")

        name_mapping = self._get_name_mapping()
        if name_mapping:
            box = layout.box()
            box.label(text=f"已应用 {len(name_mapping)} 条名称映射", icon='INFO')

        layout.separator()
        header_row = layout.row(align=True)
        header_row.prop(self, "show_detect_panel", icon='TRIA_DOWN' if self.show_detect_panel else 'TRIA_RIGHT', text="材质检测", emboss=False)

        if self.show_detect_panel:
            box = layout.box()

            prefix_row = box.row(align=True)
            prefix_row.label(text="检测前缀:", icon='FILTER')
            op = prefix_row.operator("ssmt.material_detect_add_prefix", text="", icon='ADD')
            op.node_name = self.name

            for i, item in enumerate(self.material_detect_prefixes):
                row = box.row(align=True)
                row.label(text=item.prefix, icon='MATERIAL')
                op = row.operator("ssmt.material_detect_remove_prefix", text="", icon='X')
                op.node_name = self.name
                op.item_index = i

            input_row = box.row(align=True)
            input_row.prop(self, "temp_prefix_input", text="", icon='CONSOLE')
            op = input_row.operator("ssmt.material_detect_add_custom_prefix", text="", icon='ADD')
            op.node_name = self.name

            btn_row = box.row(align=True)
            op = btn_row.operator("ssmt.material_detect", text="检测材质", icon='VIEWZOOM')
            op.node_name = self.name
            op = btn_row.operator("ssmt.material_detect_clear", text="清除", icon='X')
            op.node_name = self.name

            if self.detected_materials:
                result_box = box.box()
                result_box.label(text=f"缺失材质 ({len(self.detected_materials)} 个)", icon='ERROR')
                for item in self.detected_materials:
                    row = result_box.row(align=True)
                    row.label(text=item.object_name, icon='OBJECT_DATA')
                    row.label(text=f"缺少: {item.missing_prefix}", icon='ERROR')
            elif self.detect_all_ok:
                result_box = box.box()
                result_box.label(text="全部正确", icon='CHECKMARK')

    def extract_mesh_name(self, line):
        match = re.search(r'\[mesh:([^\]]+)\]', line)
        return match.group(1) if match else None

    def _strip_all_suffixes(self, name):
        stripped_names = []
        current = name
        max_iterations = 20
        iteration = 0
        
        suffix_patterns = [
            r'_copy$',
            r'_chain\d+$',
            r'_dup\d+$',
        ]
        
        while iteration < max_iterations:
            changed = False
            for pattern in suffix_patterns:
                new_name = re.sub(pattern, '', current)
                if new_name != current:
                    if new_name not in stripped_names:
                        stripped_names.append(new_name)
                    current = new_name
                    changed = True
                    break
            if not changed:
                break
            iteration += 1
        
        return stripped_names

    def find_object_by_mesh_name(self, mesh_name):
        from ..utils.log_utils import LOG as _LOG
        _LOG.debug(f"[find_object_by_mesh_name] 输入 mesh_name: '{mesh_name}'")
        
        reverse_mapping = self._get_reverse_name_mapping()
        name_mapping = self._get_name_mapping()
        _LOG.debug(f"  reverse_mapping 条目数: {len(reverse_mapping)}")
        _LOG.debug(f"  name_mapping 条目数: {len(name_mapping)}")

        potential_names = []

        all_stripped = self._strip_all_suffixes(mesh_name)
        for stripped in all_stripped:
            if stripped not in potential_names:
                potential_names.append(stripped)
                _LOG.debug(f"  移除后缀生成: '{stripped}'")

        potential_names.append(mesh_name)
        _LOG.debug(f"  初始 potential_names: {potential_names}")

        if reverse_mapping:
            for new_name, original_name in reverse_mapping.items():
                if new_name == mesh_name:
                    if original_name not in potential_names:
                        potential_names.append(original_name)
                        _LOG.debug(f"  反向映射精确匹配: '{new_name}' -> '{original_name}'")
                    for stripped in self._strip_all_suffixes(original_name):
                        if stripped not in potential_names:
                            potential_names.append(stripped)
                            _LOG.debug(f"  反向映射+后缀: '{original_name}' -> '{stripped}'")
                elif new_name in mesh_name:
                    original_mesh_name = mesh_name.replace(new_name, original_name)
                    if original_mesh_name not in potential_names:
                        potential_names.append(original_mesh_name)
                        _LOG.debug(f"  反向映射部分匹配: '{new_name}' in '{mesh_name}' -> '{original_mesh_name}'")
                    for stripped in self._strip_all_suffixes(original_mesh_name):
                        if stripped not in potential_names:
                            potential_names.append(stripped)
                            _LOG.debug(f"  反向映射部分+后缀: '{original_mesh_name}' -> '{stripped}'")

        if name_mapping:
            for original_name, new_name in name_mapping.items():
                if original_name in mesh_name:
                    renamed_mesh_name = mesh_name.replace(original_name, new_name)
                    if renamed_mesh_name not in potential_names:
                        potential_names.append(renamed_mesh_name)
                        _LOG.debug(f"  正向映射: '{original_name}' -> '{new_name}' in '{mesh_name}' -> '{renamed_mesh_name}'")

        _LOG.debug(f"  第一阶段 potential_names: {potential_names}")
        for name in potential_names:
            obj = bpy.data.objects.get(name)
            if obj:
                _LOG.debug(f"  ✅ 找到物体: '{name}'")
                return obj
            else:
                _LOG.debug(f"  ❌ 未找到物体: '{name}'")

        clean_name = re.sub(r'^[a-f0-9]+-[\d]+-', '', mesh_name)
        _LOG.debug(f"  清理前缀后的名称: '{clean_name}' (原: '{mesh_name}')")
        if clean_name != mesh_name:
            potential_clean_names = []

            for stripped in self._strip_all_suffixes(clean_name):
                if stripped not in potential_clean_names:
                    potential_clean_names.append(stripped)
                    _LOG.debug(f"    清理后移除后缀生成: '{stripped}'")

            potential_clean_names.append(clean_name)
            _LOG.debug(f"    初始 potential_clean_names: {potential_clean_names}")

            if name_mapping:
                for original_name, new_name in name_mapping.items():
                    if original_name in clean_name:
                        renamed_clean_name = clean_name.replace(original_name, new_name)
                        if renamed_clean_name not in potential_clean_names:
                            potential_clean_names.append(renamed_clean_name)
                            _LOG.debug(f"    清理后正向映射: '{original_name}' -> '{new_name}' -> '{renamed_clean_name}'")
                        for stripped in self._strip_all_suffixes(renamed_clean_name):
                            if stripped not in potential_clean_names:
                                potential_clean_names.append(stripped)
                                _LOG.debug(f"    清理后正向映射+后缀: '{renamed_clean_name}' -> '{stripped}'")

            if reverse_mapping:
                for new_name, original_name in reverse_mapping.items():
                    original_clean = re.sub(r'^[a-f0-9]+-[\d]+-', '', original_name)
                    if original_clean and original_clean not in potential_clean_names:
                        potential_clean_names.append(original_clean)
                        _LOG.debug(f"    反向映射原始名清理前缀: '{original_name}' -> '{original_clean}'")
                        for stripped in self._strip_all_suffixes(original_clean):
                            if stripped not in potential_clean_names:
                                potential_clean_names.append(stripped)
                                _LOG.debug(f"    反向映射原始名清理+后缀: '{original_clean}' -> '{stripped}'")
                    if new_name in clean_name:
                        original_clean_name = clean_name.replace(new_name, original_name)
                        if original_clean_name not in potential_clean_names:
                            potential_clean_names.append(original_clean_name)
                            _LOG.debug(f"    清理后反向映射部分: '{new_name}' -> '{original_clean_name}'")
                    elif new_name == clean_name:
                        if original_name not in potential_clean_names:
                            potential_clean_names.append(original_name)
                            _LOG.debug(f"    清理后反向映射精确: '{new_name}' -> '{original_name}'")

            _LOG.debug(f"  第二阶段 potential_clean_names: {potential_clean_names}")
            for name in potential_clean_names:
                obj = bpy.data.objects.get(name)
                if obj:
                    _LOG.debug(f"  ✅ 找到物体: '{name}'")
                    return obj
                else:
                    _LOG.debug(f"  ❌ 未找到物体: '{name}'")

        _LOG.debug(f"  ⚠️ 最终未找到匹配物体: '{mesh_name}'")
        return None

    def extract_transparency_info_from_mesh_name(self, mesh_name):
        match = re.search(r'(.+)_透明(\d+(\.\d+)?)', mesh_name)
        if match:
            base_name = match.group(1)
            transparency_value = match.group(2)
            shader_name = f"CustomShaderTransparencyCloth{base_name.replace('-', '_').replace('.', '_')}"
            return shader_name, transparency_value
        return None, None

    def extract_texture_type_from_resource(self, resource_name):
        match = re.search(r'_Slot_([^_]+)$', resource_name)
        if match:
            return match.group(1)

        match = re.search(r'ResourceTexture_[^=]+_(T\d+)(?:_\d+)?$', resource_name, re.IGNORECASE)
        if match:
            return match.group(1)

        match = re.search(r'Resource-.*-([^_-]+)$', resource_name)
        if match:
            return match.group(1)

        return None

    @staticmethod
    def _parse_ps_texture_material_slot(material_name):
        clean_name = str(material_name or "").strip()
        if not clean_name:
            return None
        match = re.match(r'^(?:ps[-_ ]*)?t(\d+)(?:[_\-. ].*)?$', clean_name, re.IGNORECASE)
        if not match:
            return None

        slot_number = str(int(match.group(1)))
        return f"ps-t{slot_number}", f"T{slot_number}"

    @staticmethod
    def _resource_token(value):
        token = re.sub(r"[^0-9A-Za-z_]+", "_", str(value or "").strip())
        token = token.strip("_")
        return token or "part"

    @staticmethod
    def _resource_name_token(value):
        token = re.sub(r"[^0-9A-Za-z_.-]+", "_", str(value or "").strip())
        token = token.strip("_.-")
        return token or "Texture"

    @staticmethod
    def _material_resource_stem(material):
        material_name = str(getattr(material, "name", "") or "").strip()
        if not material_name:
            material_name = "Texture"
        stem = re.sub(r'[\r\n\[\]=<>:"/\\|?*\s]+', "_", material_name).strip()
        return stem.strip("._") or "Texture"

    @staticmethod
    def _normalize_ps_texture_slot_label(value):
        clean_value = str(value or "").strip()
        if not clean_value:
            return None
        match = re.match(r'^(?:ps[-_ ]*)?t(\d+)$', clean_value, re.IGNORECASE)
        if not match:
            return None
        slot_number = str(int(match.group(1)))
        return f"ps-t{slot_number}", f"T{slot_number}"

    @classmethod
    def _infer_ps_texture_slot_label(cls, *values):
        for value in values:
            normalized_slot = cls._normalize_ps_texture_slot_label(value)
            if normalized_slot:
                return normalized_slot

            basename = os.path.basename(str(value or ""))
            match = re.search(r'(?:^|[-_])t(\d+)(?:[-_.]|$)', basename, re.IGNORECASE)
            if match:
                slot_number = str(int(match.group(1)))
                return f"ps-t{slot_number}", f"T{slot_number}"

        return None

    def _object_texture_resource_identity(self, obj):
        try:
            from ..common.object_prefix_helper import ObjectPrefixHelper
        except Exception:
            ObjectPrefixHelper = None

        candidate_names = []

        def append_candidate_name(name):
            name = str(name or "").strip()
            if name and name not in candidate_names:
                candidate_names.append(name)

        if obj:
            append_candidate_name(getattr(obj, "name", ""))
            append_candidate_name(getattr(obj, "original_object_name", ""))
            for stripped_name in self._strip_all_suffixes(getattr(obj, "name", "")):
                append_candidate_name(stripped_name)

            if ObjectPrefixHelper is not None:
                try:
                    append_candidate_name(ObjectPrefixHelper.resolve_source_object_name(obj.name))
                except Exception:
                    pass

        if ObjectPrefixHelper is not None:
            for name in candidate_names:
                try:
                    prefix_info = ObjectPrefixHelper.extract_prefix_info(name)
                except Exception:
                    prefix_info = None
                if not prefix_info:
                    continue
                prefix, _ = prefix_info
                parts = ObjectPrefixHelper.parse_prefix_parts(prefix)
                draw_ib = str(parts.get("draw_ib", "") or "").strip()
                index_count = str(parts.get("index_count", "") or "").strip()
                first_index = str(parts.get("first_index", "") or "").strip()
                if draw_ib and index_count and first_index:
                    return f"{draw_ib}-{index_count}-{first_index}"
                if draw_ib:
                    return draw_ib

        for name in candidate_names:
            clean_name = str(name or "").strip()
            if not clean_name:
                continue
            clean_name = re.sub(r"^LOD\d+\.", "", clean_name, flags=re.IGNORECASE)
            prefix_candidate = clean_name.split(".", 1)[0]
            match = re.match(r'^([A-Za-z0-9]{6,})[-_](\d+)[-_](\d+)', prefix_candidate)
            if match:
                return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
            match = re.match(r'^([A-Za-z0-9]{6,})', prefix_candidate)
            if match:
                return match.group(1)

        return self._resource_name_token(getattr(obj, "name", "") if obj else "")

    def _object_texture_resource_token(self, obj):
        return self._resource_token(self._object_texture_resource_identity(obj))

    def _ps_texture_resource_name(self, obj, slot_label):
        slot_token = str(slot_label or "").replace("ps-", "").replace("-", "_").upper()
        return f"ResourceTexture_{self._object_texture_resource_token(obj)}_{slot_token}"

    @staticmethod
    def _ps_texture_material_resource_name(material):
        return f"ResourceTexture_{SSMTNode_PostProcess_Material._material_resource_stem(material)}"

    def _collect_ntmi_cached_texture_slots_raw(self, obj):
        if obj is None:
            return ""
        try:
            from ..ui.ntmi_modimp.prefix_property_cache import get_prefix_record_props, has_prefix_record
        except Exception:
            return ""

        try:
            cached_props = get_prefix_record_props(getattr(obj, "name", ""))
            has_cached_record = has_prefix_record(getattr(obj, "name", ""))
        except Exception:
            return ""
        if not has_cached_record:
            return None
        if not isinstance(cached_props, dict):
            return ""

        workspace_unique_str = str(cached_props.get("modimp_workspace_unique_str", "") or "").strip()
        profile_id = str(cached_props.get("modimp_profile_id", "") or "").strip().lower()
        if not workspace_unique_str and profile_id not in {"yihuan", "ntemi"}:
            return ""

        return str(cached_props.get("modimp_texture_slots", "") or "").strip()

    def _collect_modimp_texture_slots(self, obj):
        import json as _json

        result = OrderedDict()
        raw = self._collect_ntmi_cached_texture_slots_raw(obj)
        if raw is None:
            raw = str(obj.get("modimp_texture_slots", "") or "").strip()
        if not raw:
            return result
        try:
            slots = _json.loads(raw) if isinstance(raw, str) else raw
        except Exception:
            return result
        if not isinstance(slots, dict):
            return result

        for slot_label, binding in slots.items():
            if not isinstance(binding, dict):
                continue
            mark_name = str(binding.get("mark_name", "") or "").strip()
            source_path = str(binding.get("source_path", "") or "").strip()
            normalized_slot = self._infer_ps_texture_slot_label(
                slot_label,
                binding.get("mark_slot", ""),
                binding.get("slot", ""),
                source_path,
                binding.get("mark_filename", ""),
            )
            if not normalized_slot:
                continue
            if not mark_name:
                continue
            param_name, slot_token = normalized_slot
            slot_info = dict(binding)
            slot_info["param_name"] = param_name
            slot_info["slot_token"] = slot_token
            slot_info["mark_name"] = mark_name
            slot_info["source_path"] = source_path
            result[param_name] = slot_info
        return result

    def _workspace_material_output_filename(self, material, source_path=None):
        source_path = str(source_path or "").strip()
        source_extension = os.path.splitext(source_path)[1] or ".dds"
        return f"{self._material_resource_stem(material)}{source_extension}"

    def _workspace_material_resource_name(self, material):
        return f"Resource-{self._material_resource_stem(material)}"

    @staticmethod
    def _clone_generated_param_lines(lines, source_param, target_param):
        if not lines:
            return []

        source_param = str(source_param or "").strip()
        target_param = str(target_param or "").strip()
        if not source_param or not target_param or source_param == target_param:
            return []

        assignment_re = re.compile(
            rf"^(?P<indent>\s*){re.escape(source_param)}\s*=\s*(?:(?P<ref>ref)\s+)?(?P<resource>.+?)\s*$",
            re.IGNORECASE,
        )
        alias_lines = []
        target_is_resource_ref = target_param.lower().startswith("resource\\")

        for line in lines:
            match = assignment_re.match(str(line or ""))
            if not match:
                continue

            indent = match.group("indent") or ""
            resource_name = str(match.group("resource") or "").strip()
            if target_is_resource_ref:
                alias_lines.append(f"{indent}{target_param} = ref {resource_name}")
            else:
                alias_lines.append(f"{indent}{target_param} = {resource_name}")

        return alias_lines

    @staticmethod
    def _find_first_slot_by_mark_name(slot_map, mark_name):
        target_mark_name = str(mark_name or "").strip().lower()
        if not target_mark_name:
            return ""

        for param_name, slot_info in (slot_map or {}).items():
            current_mark_name = str(getattr(slot_info, "get", lambda *_args, **_kwargs: "")("mark_name", "") or "").strip().lower()
            if current_mark_name == target_mark_name:
                return str(param_name or "").strip().lower()
        return ""

    @staticmethod
    def _ensure_alias_assignment_in_lines(lines, source_param, target_param):
        source_param = str(source_param or "").strip()
        target_param = str(target_param or "").strip()
        if not source_param or not target_param or source_param == target_param:
            return False

        source_re = re.compile(
            rf"^(?P<indent>\s*){re.escape(source_param)}\s*=\s*(?:(?P<ref>ref)\s+)?(?P<resource>.+?)\s*$",
            re.IGNORECASE,
        )
        target_re = re.compile(
            rf"^\s*{re.escape(target_param)}\s*=",
            re.IGNORECASE,
        )

        if any(target_re.match(str(line or "")) for line in lines):
            return False

        for index, line in enumerate(lines):
            match = source_re.match(str(line or ""))
            if not match:
                continue
            indent = match.group("indent") or ""
            resource_name = str(match.group("resource") or "").strip()
            lines.insert(index, f"{indent}{target_param} = {resource_name}")
            return True

        return False

    def _find_workspace_slot_materials(self, obj, slot_info):
        mark_name = str(slot_info.get("mark_name", "") or "").strip()
        if not mark_name:
            return []

        texture_type_lower = mark_name.lower()
        
        def find_materials_in_object(target_obj):
            matching_materials = OrderedDict()
            for material_slot in getattr(target_obj, "material_slots", []):
                material = material_slot.material
                if not material:
                    continue
                material_name = str(getattr(material, "name", "") or "")
                if texture_type_lower == "fxmap" and not material_name.lower().startswith("fxmap_"):
                    continue
                if not material_name.lower().startswith(texture_type_lower):
                    continue
                material_first_word = material_name.split('_')[0].lower()
                if material_first_word != texture_type_lower:
                    continue
                signature = self._build_material_signature(material)
                if signature not in matching_materials:
                    matching_materials[signature] = material
            return list(matching_materials.values())
        
        if obj:
            obj_materials = find_materials_in_object(obj)
            if obj_materials:
                return obj_materials

        return []

    def _create_workspace_texture_resource_entry(self, obj, slot_info, texture_folder, all_sections, texture_ini_folder="Textures"):
        material = next(iter(self._find_workspace_slot_materials(obj, slot_info)), None)
        if not material:
            return None, None
        texture_image = self.get_texture_from_material(material)
        if not texture_image:
            return None, None
        source_path = bpy.path.abspath(getattr(texture_image, "filepath", "") or "")
        if not source_path or not os.path.exists(source_path):
            return None, None

        os.makedirs(texture_folder, exist_ok=True)
        output_filename = self._workspace_material_output_filename(material, source_path=source_path)
        target_path = os.path.join(texture_folder, output_filename)

        try:
            source_abs = os.path.abspath(source_path)
            target_abs = os.path.abspath(target_path)
            if source_abs != target_abs:
                if self.material_to_resource_override or not os.path.exists(target_path):
                    shutil.copy2(source_path, target_path)
        except Exception as e:
            print(f"复制工作空间贴图失败: {e}")
            return None, None

        resource_name = self._workspace_material_resource_name(material)
        resource_section_name = f"[{resource_name}]"
        texture_ini_folder = str(texture_ini_folder or "Textures").strip().strip("\\/")
        desired_line = f"filename = {texture_ini_folder}/{output_filename}".replace("\\", "/")
        existing_lines = all_sections.get(resource_section_name, [])
        existing_normalized = {
            line.strip().replace("\\", "/")
            for line in existing_lines
        }
        if self.material_to_resource_override or desired_line not in existing_normalized:
            all_sections[resource_section_name] = [desired_line]

        param_name = slot_info.get("param_name", "")
        return f"{param_name} = {resource_name}", resource_name

    def _has_strict_fxmap_material(self, obj):
        if not obj:
            return False
        for material_slot in getattr(obj, "material_slots", []):
            material = material_slot.material
            material_name = str(getattr(material, "name", "") or "")
            if material_name.lower().startswith("fxmap_"):
                return True
        return False

    def _collect_ntemifx_texture_slots(self, obj, workspace_resource_by_slot=None) -> dict[str, str]:
        result: dict[str, str] = {}
        if not self._has_strict_fxmap_material(obj):
            return result

        if workspace_resource_by_slot:
            for slot_label, slot_info in workspace_resource_by_slot.items():
                mark_name = str(slot_info.get("mark_name", "") or "").strip()
                resource_name = str(slot_info.get("resource_name", "") or "").strip()
                if mark_name == "FXMap" and resource_name:
                    result[slot_label] = resource_name
            return result

        for slot_label, slot_info in self._collect_modimp_texture_slots(obj).items():
            mark_name = str(slot_info.get("mark_name", "") or "").strip()
            if mark_name != "FXMap":
                continue
            material = next(iter(self._find_workspace_slot_materials(obj, slot_info)), None)
            if material:
                result[slot_label] = self._workspace_material_resource_name(material)
        return result

    def _collect_ps_texture_slot_materials(self, obj):
        slot_to_materials = OrderedDict()
        if not obj:
            return slot_to_materials

        def collect_from_object(target_obj):
            result = OrderedDict()
            for material_slot in getattr(target_obj, "material_slots", []):
                material = material_slot.material
                if not material:
                    continue
                parsed_slot = self._parse_ps_texture_material_slot(material.name)
                if not parsed_slot:
                    continue
                param_name, texture_type = parsed_slot
                slot_info = result.setdefault(
                    param_name,
                    {
                        "texture_type": texture_type,
                        "materials": OrderedDict(),
                    },
                )
                signature = self._build_material_signature(material)
                if signature not in slot_info["materials"]:
                    slot_info["materials"][signature] = material
            return result
        
        obj_slots = collect_from_object(obj)
        if obj_slots:
            return obj_slots

        return slot_to_materials

    def build_mapping_for_section(self, lines):
        mapping = OrderedDict()
        line_pattern = re.compile(r'^(ps-t\d+|Resource\\[^\s=]+)\s*=\s*(?:ref\s+)?(.*)$')
        for line in lines:
            resource_match = line_pattern.match(line.strip())
            if resource_match:
                param_name = resource_match.group(1).strip()
                resource_name = resource_match.group(2).strip()
                texture_type = self.extract_texture_type_from_resource(resource_name)
                if texture_type:
                    mapping[param_name] = texture_type
        return mapping

    def find_matching_materials(self, obj, texture_type):
        texture_type_lower = texture_type.lower()

        def find_in_object(target_obj):
            result = OrderedDict()
            for material_slot in getattr(target_obj, "material_slots", []):
                material = material_slot.material
                if not material:
                    continue
                if texture_type_lower == "fxmap" and not material.name.lower().startswith("fxmap_"):
                    continue
                if not material.name.lower().startswith(texture_type_lower):
                    continue
                material_first_word = material.name.split('_')[0].lower()
                if material_first_word == texture_type_lower:
                    signature = self._build_material_signature(material)
                    if signature not in result:
                        result[signature] = material
            return list(result.values())
        
        if obj:
            obj_materials = find_in_object(obj)
            if obj_materials:
                return obj_materials

        return []

    @staticmethod
    def _build_material_signature(material):
        if not material:
            return ("",)

        material_name = str(getattr(material, "name", "") or "")
        type_prefix = material_name.split('_')[0].lower()
        
        main_texture_path = None
        if getattr(material, "use_nodes", False) and getattr(material, "node_tree", None):
            try:
                output_node = next(n for n in material.node_tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output)
                surface_input = output_node.inputs.get('Surface')
                if surface_input and surface_input.is_linked:
                    def find_texture_node_recursively(node):
                        if node.type == 'TEX_IMAGE' and node.image:
                            image = node.image
                            return bpy.path.abspath(getattr(image, "filepath", "") or "") or image.name
                        for input_socket in node.inputs:
                            if input_socket.is_linked:
                                found = find_texture_node_recursively(input_socket.links[0].from_node)
                                if found: return found
                        return None
                    main_texture_path = find_texture_node_recursively(surface_input.links[0].from_node)
            except (StopIteration, AttributeError):
                pass
            
            if not main_texture_path:
                for node in material.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        image = node.image
                        main_texture_path = bpy.path.abspath(getattr(image, "filepath", "") or "") or image.name
                        break

        if main_texture_path:
            return (type_prefix, main_texture_path)
        return (type_prefix, material_name)

    def get_texture_from_material(self, material):
        if not material or not material.use_nodes:
            return None
        try:
            output_node = next(n for n in material.node_tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output)
            surface_input = output_node.inputs.get('Surface')
            if surface_input and surface_input.is_linked:
                def find_texture_node_recursively(node):
                    if node.type == 'TEX_IMAGE' and node.image:
                        return node.image
                    for input_socket in node.inputs:
                        if input_socket.is_linked:
                            found_image = find_texture_node_recursively(input_socket.links[0].from_node)
                            if found_image: return found_image
                    return None
                linked_image = find_texture_node_recursively(surface_input.links[0].from_node)
                if linked_image: return linked_image
        except (StopIteration, AttributeError):
            pass
        for node in material.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                return node.image
        return None

    def copy_texture_file(self, texture_image, target_folder, material, forced_filename=None):
        if not texture_image or not texture_image.filepath:
            return None
        try:
            source_path = bpy.path.abspath(texture_image.filepath)
            if not os.path.exists(source_path): return None
            os.makedirs(target_folder, exist_ok=True)

            if forced_filename:
                new_filename = forced_filename
            else:
                _, file_extension = os.path.splitext(os.path.basename(source_path))
                new_filename = f"{material.name}{file_extension}"

            target_path = os.path.join(target_folder, new_filename)
            if os.path.exists(target_path) and not self.material_to_resource_override:
                return new_filename
            shutil.copy2(source_path, target_path)
            return new_filename
        except Exception as e:
            print(f"复制纹理文件失败: {e}")
            return None

    def _read_ini_to_ordered_dict(self, ini_file_path):
        sections = OrderedDict()
        current_section = None
        try:
            with open(ini_file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    stripped_line = line.strip()
                    if stripped_line.startswith('[') and stripped_line.endswith(']'):
                        current_section = stripped_line
                        sections[current_section] = []
                    elif not stripped_line:
                        continue
                    elif current_section is not None:
                        sections[current_section].append(line.rstrip())
        except FileNotFoundError:
            return None
        return sections

    def _write_ordered_dict_to_ini(self, sections, ini_file_path):
        with open(ini_file_path, 'w', encoding='utf-8') as f:
            for section_name, lines in sections.items():
                f.write(f"{section_name}\n")
                for line in lines:
                    f.write(f"{line}\n")
                f.write("\n")

    def define_swapkeys_in_sections(self, sections, keys_to_define):
        if not keys_to_define: return
        if '[Constants]' not in sections:
            new_sections = OrderedDict([('[Constants]', [])])
            new_sections.update(sections)
            sections.clear()
            sections.update(new_sections)
        constants_lines = sections['[Constants]']
        existing_definitions = "".join(constants_lines)
        for key in sorted(list(keys_to_define)):
            if key not in existing_definitions:
                definition = f"global persist {key} = 0"
                constants_lines.append(definition)

    def generate_material_lines(self, matching_materials, param_name, texture_type, obj,
                                texture_folder, all_sections,
                                object_to_diffuse_swapkey, material_group_to_swapkey,
                                swap_key_prefix, next_swap_key_num, used_swap_keys,
                                resource_name_provider=None):
        generated_lines = []
        brightness_param_name = r"$\RabbitFX\brightness"

        if len(matching_materials) == 1:
            material = matching_materials[0]
            if texture_type == 'Glowmap':
                match = re.search(r'^Glowmap_(\d+)_', material.name, re.IGNORECASE)
                if match:
                    generated_lines.append(f"{brightness_param_name} = {match.group(1)}")

            resource_name = resource_name_provider(material, 0) if resource_name_provider else None
            new_line = self.create_resource_entry(
                material,
                param_name,
                texture_folder,
                all_sections,
                resource_name_override=resource_name,
            )
            if new_line:
                generated_lines.append(new_line)

        elif len(matching_materials) > 1:
            current_swap_variable = None
            if texture_type != 'DiffuseMap' and obj.name in object_to_diffuse_swapkey:
                current_swap_variable = object_to_diffuse_swapkey[obj.name]
            else:
                mat_names_tuple = tuple(sorted([mat.name for mat in matching_materials]))
                if mat_names_tuple not in material_group_to_swapkey:
                    new_swap_key = f"{swap_key_prefix}{next_swap_key_num}"
                    material_group_to_swapkey[mat_names_tuple] = new_swap_key
                    next_swap_key_num += 1
                current_swap_variable = material_group_to_swapkey[mat_names_tuple]

                if texture_type == 'DiffuseMap':
                    object_to_diffuse_swapkey[obj.name] = current_swap_variable

            used_swap_keys.add(current_swap_variable)

            generated_lines.append(f"; {texture_type} 材质切换 (组: {current_swap_variable})")
            for index, material in enumerate(matching_materials):
                resource_name = resource_name_provider(material, index) if resource_name_provider else None
                new_line = self.create_resource_entry(
                    material,
                    param_name,
                    texture_folder,
                    all_sections,
                    resource_name_override=resource_name,
                )
                if new_line:
                    generated_lines.append(f"if {current_swap_variable} == {index}")
                    if texture_type == 'Glowmap':
                        match = re.search(r'^Glowmap_(\d+)_', material.name, re.IGNORECASE)
                        if match:
                            generated_lines.append(f"    {brightness_param_name} = {match.group(1)}")
                    generated_lines.append(f"    {new_line}")
                    generated_lines.append("endif")
            generated_lines.append("")

        return generated_lines, next_swap_key_num

    def create_resource_entry(self, material, param_name, texture_folder, all_sections, resource_name_override=None):
        global _material_resource_cache

        texture_image = self.get_texture_from_material(material)
        if not texture_image: return None

        # 同内容材质复用同一个 Resource 名称，避免材质后处理把同图资源反复写出。
        material_signature = self._build_material_signature(material)
        resource_name_override = str(resource_name_override or "").strip()
        cache_key = material_signature if not resource_name_override else (material_signature, resource_name_override)
        cached_entry = _material_resource_cache.get(cache_key)

        if cached_entry:
            resource_name = cached_entry.get(
                "resource_name",
                resource_name_override or f"Resource_{self._material_resource_stem(material)}",
            )
            copied_filename = self.copy_texture_file(
                texture_image,
                texture_folder,
                material,
                forced_filename=cached_entry.get("filename"),
            )
        else:
            copied_filename = self.copy_texture_file(texture_image, texture_folder, material)
            resource_name = resource_name_override or f"Resource_{self._material_resource_stem(material)}"
            if copied_filename:
                _material_resource_cache[cache_key] = {
                    "resource_name": resource_name,
                    "filename": copied_filename,
                }

        if not copied_filename: return None
        resource_section_name = f"[{resource_name}]"
        desired_line = f"filename = Textures/{copied_filename}".replace("\\", "/")
        existing_lines = all_sections.get(resource_section_name, [])
        existing_normalized = {
            line.strip().replace("\\", "/")
            for line in existing_lines
        }
        if self.material_to_resource_override or desired_line not in existing_normalized:
            all_sections[resource_section_name] = [desired_line]
        return "{} = {}".format(param_name, resource_name) if not param_name.lower().startswith("resource\\") else "{} = ref {}".format(param_name, resource_name)

    @staticmethod
    def _is_generated_material_line(line: str) -> bool:
        stripped = line.strip()
        if not stripped:
            return False

        generated_prefixes = (
            "Resource\\RabbitFX\\",
            "Resource\\RabbitFx\\",
            "Resource\\ZZMI\\",
            "Resource\\NTEMIFX\\",
            "ps-t",
            "$\\RabbitFX\\brightness",
        )
        generated_exact = {
            "run = CommandList\\RabbitFX\\SetTextures",
            "run = CommandList\\RabbitFx\\SetTextures",
            "run = CommandList\\ZZMI\\SetTextures",
            "run = CommandList\\RabbitFX\\Run",
            "run = CommandList\\NTEMIFX\\Run",
        }
        return (
            stripped in generated_exact
            or stripped.startswith(generated_prefixes)
            or "材质切换" in stripped
        )

    def _is_material_switch_if_line(self, line: str) -> bool:
        base_var = str(getattr(self, "material_switch_var", "") or "").strip()
        if not base_var:
            return False

        match = re.match(r"^if\s+(\$\w+?)(\d+)\s*==", line.strip())
        base_match = re.match(r"^(\$\w+?)(\d+)$", base_var)
        if match and base_match:
            var_prefix, var_index = match.groups()
            base_prefix, base_index = base_match.groups()
            return var_prefix == base_prefix and int(var_index) >= int(base_index)

        return line.strip().startswith(f"if {base_var} ")

    def _find_mesh_block_reset_insert_index(self, lines, mesh_start_index: int) -> int:
        search_end_idx = len(lines)
        for i in range(mesh_start_index + 1, len(lines)):
            if '[mesh:' in lines[i]:
                search_end_idx = i
                break

        draw_idx = -1
        for i in range(mesh_start_index + 1, search_end_idx):
            if 'drawindexed' in lines[i]:
                draw_idx = i
                break
        if draw_idx == -1:
            return -1

        block_depth = 0
        last_endif_idx = -1
        for i in range(mesh_start_index + 1, search_end_idx):
            stripped = lines[i].strip()
            if stripped.startswith("if "):
                block_depth += 1
            elif stripped == "endif":
                if block_depth > 0:
                    block_depth -= 1
                last_endif_idx = i

        if last_endif_idx > draw_idx:
            return last_endif_idx + 1
        return draw_idx + 1

    def _strip_generated_material_lines(self, lines, preserved_ps_slots=None):
        cleaned_lines = []
        inside_mesh_block = False
        skipping_material_switch_block = False
        preserved_ps_slots = {
            str(slot or "").strip().lower()
            for slot in (preserved_ps_slots or [])
            if str(slot or "").strip()
        }

        for line in lines:
            if self.extract_mesh_name(line):
                inside_mesh_block = True
                skipping_material_switch_block = False
                cleaned_lines.append(line)
                continue

            stripped = line.strip()
            if inside_mesh_block and self._is_material_switch_if_line(stripped):
                skipping_material_switch_block = True
                continue

            if skipping_material_switch_block:
                if stripped == "endif":
                    skipping_material_switch_block = False
                continue

            if inside_mesh_block and self._is_generated_material_line(stripped):
                ps_match = re.match(r"^(ps-t\d+)\s*=", stripped, re.IGNORECASE)
                if ps_match and ps_match.group(1).strip().lower() in preserved_ps_slots:
                    cleaned_lines.append(line)
                    continue
                continue

            cleaned_lines.append(line)

        return cleaned_lines

    def process_texture_override_section(self, section_name, all_sections,
                                          material_group_to_swapkey, swap_key_prefix=None, next_swap_key_num=None,
                                          used_swap_keys=None, transparency_sections_to_add=None):
        from ..utils.log_utils import LOG as _LOG
        if material_group_to_swapkey is None or material_group_to_swapkey is Ellipsis:
            material_group_to_swapkey = {}
        if used_swap_keys is None or used_swap_keys is Ellipsis:
            used_swap_keys = set()
        if transparency_sections_to_add is None or transparency_sections_to_add is Ellipsis:
            transparency_sections_to_add = OrderedDict()
        if swap_key_prefix is Ellipsis:
            swap_key_prefix = None
        if next_swap_key_num is Ellipsis:
            next_swap_key_num = None
        if swap_key_prefix is None or next_swap_key_num is None:
            base_swap_var = getattr(self, "material_switch_var", "") or "$swapkey0"
            match = re.match(r'(\$\w+)(\d+)', str(base_swap_var))
            swap_key_prefix = match.group(1) if match else str(base_swap_var)
            next_swap_key_num = int(match.group(2)) if match else 0

        lines = all_sections[section_name]
        mesh_line = next((line for line in lines if self.extract_mesh_name(line)), "")
        section_mesh_name = self.extract_mesh_name(mesh_line) or ""
        section_obj = self.find_object_by_mesh_name(section_mesh_name) if section_mesh_name else None

        if section_mesh_name and section_obj is None:
            return next_swap_key_num

        ini_mapping = self.build_mapping_for_section(lines)
        preserved_ps_slots = set()
        workspace_slots = OrderedDict()
        if getattr(self, "_ntmi_modimp_extra_ps_t2_diffuse_map", False):
            if section_obj is not None:
                workspace_slots = self._collect_modimp_texture_slots(section_obj)
        diffuse_workspace_slot = self._find_first_slot_by_mark_name(workspace_slots, "DiffuseMap")
        if getattr(self, "_ntmi_modimp_extra_ps_t2_diffuse_map", False) and diffuse_workspace_slot and diffuse_workspace_slot != "ps-t2":
            _self_alias_inserted = self._ensure_alias_assignment_in_lines(lines, diffuse_workspace_slot, "ps-t2")
            if _self_alias_inserted:
                ini_mapping["ps-t2"] = ini_mapping.get(diffuse_workspace_slot, "DiffuseMap")
                preserved_ps_slots.add("ps-t2")
        lines[:] = self._strip_generated_material_lines(lines, preserved_ps_slots=preserved_ps_slots)
        config_path = os.path.normpath(all_sections.get('_config_path', ''))
        workspace_texture_ini_folder = "Textures"
        workspace_texture_folder = os.path.join(config_path, workspace_texture_ini_folder)
        texture_folder = os.path.join(config_path, "Textures")
        object_to_diffuse_swapkey = {}

        mesh_lines_info_phase1 = [(i, self.extract_mesh_name(line)) for i, line in enumerate(lines) if self.extract_mesh_name(line)]
        
        for insert_index, mesh_name in reversed(mesh_lines_info_phase1):
            obj = self.find_object_by_mesh_name(mesh_name)
            if not obj:
                continue
            if not obj.material_slots:
                continue
            
            matched_types = []
            
            new_lines_for_this_mesh = []
            generated_zzmi_style, generated_rabbitfx_style, generated_glowmap, generated_fxmap = False, False, False, False
            generated_ps_slots = set()

            workspace_resource_by_slot = OrderedDict()
            diffuse_workspace_slot = ""
            for param_name, slot_info in self._collect_modimp_texture_slots(obj).items():
                texture_type = str(slot_info.get("mark_name", "") or "").strip()
                if not texture_type or texture_type == "FXMap":
                    continue
                if not diffuse_workspace_slot and texture_type == "DiffuseMap":
                    diffuse_workspace_slot = str(param_name or "").strip().lower()
                matching_materials = self._find_workspace_slot_materials(obj, slot_info)
                if not matching_materials:
                    continue
                matched_types.append(texture_type)
                generated_lines, next_swap_key_num = self.generate_material_lines(
                    matching_materials, param_name, texture_type, obj, workspace_texture_folder, all_sections,
                    object_to_diffuse_swapkey, material_group_to_swapkey,
                    swap_key_prefix, next_swap_key_num, used_swap_keys)
                if generated_lines:
                    new_lines_for_this_mesh.extend(generated_lines)
                    generated_ps_slots.add(param_name.lower())
                    workspace_resource_by_slot[param_name] = {
                        **dict(slot_info),
                        "resource_name": self._workspace_material_resource_name(matching_materials[0]),
                    }

            if (
                getattr(self, "_ntmi_modimp_extra_ps_t2_diffuse_map", False)
                and diffuse_workspace_slot
                and diffuse_workspace_slot in generated_ps_slots
                and "ps-t2" not in generated_ps_slots
            ):
                diffuse_alias_lines = self._clone_generated_param_lines(
                    new_lines_for_this_mesh,
                    diffuse_workspace_slot,
                    "ps-t2",
                )
                if diffuse_alias_lines:
                    new_lines_for_this_mesh.extend(diffuse_alias_lines)
                    generated_ps_slots.add("ps-t2")
                    matched_types.append("DiffuseMap->ps-t2")

            is_pst_style = any(k.lower().startswith("ps-t") for k in ini_mapping.keys())
            is_zzmi_style = any(k.lower().startswith("resource\\zzmi\\") for k in ini_mapping.keys())
            is_rabbitfx_style = any(k.lower().startswith("resource\\rabbitfx\\") for k in ini_mapping.keys())
            if is_pst_style or is_zzmi_style or is_rabbitfx_style:
                for param_name, texture_type in ini_mapping.items():
                    is_zzmi_param = param_name.lower().startswith("resource\\zzmi\\")
                    is_rabbitfx_param = param_name.lower().startswith("resource\\rabbitfx\\")

                    if not is_zzmi_param and not is_rabbitfx_param and not param_name.lower().startswith("ps-t"):
                        continue
                    if texture_type == "FXMap" and param_name.lower().startswith("ps-t"):
                        continue
                    if param_name.lower() in generated_ps_slots:
                        continue
                    matching_materials = self.find_matching_materials(obj, texture_type)
                    if matching_materials:
                        matched_types.append(texture_type)
                        if is_zzmi_param:
                            generated_zzmi_style = True
                        elif is_rabbitfx_param:
                            generated_rabbitfx_style = True
                        resource_name_provider = None
                        if param_name.lower().startswith("ps-t"):
                            resource_name_provider = lambda material, index: self._ps_texture_material_resource_name(material)
                        generated_lines, next_swap_key_num = self.generate_material_lines(
                            matching_materials, param_name, texture_type, obj, texture_folder, all_sections,
                            object_to_diffuse_swapkey, material_group_to_swapkey,
                            swap_key_prefix, next_swap_key_num, used_swap_keys,
                            resource_name_provider=resource_name_provider)
                        new_lines_for_this_mesh.extend(generated_lines)
                        if param_name.lower().startswith("ps-t"):
                            generated_ps_slots.add(param_name.lower())

            slot_materials = self._collect_ps_texture_slot_materials(obj)
            for param_name, slot_info in slot_materials.items():
                if param_name.lower() in generated_ps_slots:
                    continue
                texture_type = slot_info["texture_type"]
                matching_materials = list(slot_info["materials"].values())
                if not matching_materials:
                    continue
                matched_types.append(texture_type)
                resource_name_provider = lambda material, index: self._ps_texture_material_resource_name(material)
                generated_lines, next_swap_key_num = self.generate_material_lines(
                    matching_materials, param_name, texture_type, obj, texture_folder, all_sections,
                    object_to_diffuse_swapkey, material_group_to_swapkey,
                    swap_key_prefix, next_swap_key_num, used_swap_keys,
                    resource_name_provider=resource_name_provider)
                new_lines_for_this_mesh.extend(generated_lines)

            if (
                getattr(self, "_ntmi_modimp_extra_ps_t2_diffuse_map", False)
                and diffuse_workspace_slot
                and "ps-t2" not in generated_ps_slots
            ):
                diffuse_alias_lines = self._clone_generated_param_lines(
                    new_lines_for_this_mesh,
                    diffuse_workspace_slot,
                    "ps-t2",
                )
                if diffuse_alias_lines:
                    new_lines_for_this_mesh.extend(diffuse_alias_lines)
                    generated_ps_slots.add("ps-t2")
                    matched_types.append("DiffuseMap->ps-t2")

            fxmap_lines = []
            for texture_type in ['Glowmap', 'FXMap']:
                matching_materials = self.find_matching_materials(obj, texture_type)
                if matching_materials:
                    matched_types.append(texture_type)
                    fx_namespace = "NTEMIFX" if GlobalConfig.logic_name == LogicName.NTEMI else "RabbitFX"
                    param_name = f"Resource\\{fx_namespace}\\{texture_type}"
                    if texture_type == 'Glowmap': generated_glowmap = True
                    if texture_type == 'FXMap': generated_fxmap = True
                    generated_lines, next_swap_key_num = self.generate_material_lines(
                        matching_materials, param_name, texture_type, obj, texture_folder, all_sections,
                        object_to_diffuse_swapkey, material_group_to_swapkey,
                        swap_key_prefix, next_swap_key_num, used_swap_keys)
                    fxmap_lines.extend(generated_lines)
                    fxmap_lines.append(f"run = CommandList\\{fx_namespace}\\Run")

            ntemifx_lines = []
            ntemifx_texture_slots = self._collect_ntemifx_texture_slots(obj, workspace_resource_by_slot)
            for slot_label, resource_name in ntemifx_texture_slots.items():
                ntemifx_lines.append(f"Resource\\NTEMIFX\\FXMap = ref {resource_name}")
                ntemifx_lines.append("run = CommandList\\NTEMIFX\\Run")
                matched_types.append(f"NTEMIFX/{slot_label}")
            if ntemifx_texture_slots:
                reset_after_draw = []
                reset_after_draw.append("Resource\\NTEMIFX\\FXMap = ref null")
                reset_after_draw.append("run = CommandList\\NTEMIFX\\Run")
                reset_insert_idx = self._find_mesh_block_reset_insert_index(lines, insert_index)
                if reset_insert_idx != -1:
                    lines[reset_insert_idx:reset_insert_idx] = reset_after_draw
            
            if matched_types:
                _LOG.info(f"      找到 '{mesh_name}', 匹配材质: {', '.join(matched_types)}")
            else:
                _LOG.info(f"      找到 '{mesh_name}', 未匹配到材质")
            
            if generated_zzmi_style: new_lines_for_this_mesh.append("run = CommandList\\ZZMI\\SetTextures")
            if generated_rabbitfx_style: new_lines_for_this_mesh.append("run = CommandList\\RabbitFX\\SetTextures")
            new_lines_for_this_mesh.extend(fxmap_lines)
            new_lines_for_this_mesh.extend(ntemifx_lines)
            lines[insert_index + 1:insert_index + 1] = new_lines_for_this_mesh
            reset_lines = []
            if GlobalConfig.logic_name == LogicName.NTEMI:
                if generated_glowmap:
                    reset_lines.extend(["Resource\\NTEMIFX\\Glowmap = ref null", r"$\NTEMIFX\brightness = 0"])
                if generated_fxmap:
                    reset_lines.append("Resource\\NTEMIFX\\FXMap = ref null")
            else:
                if generated_glowmap:
                    reset_lines.extend(["Resource\\RabbitFX\\Glowmap = ref null", r"$\RabbitFX\brightness = 0"])
                if generated_fxmap:
                    reset_lines.append("Resource\\RabbitFX\\FXMap = ref null")
            if reset_lines:
                reset_lines.append("run = CommandList\\NTEMIFX\\Run" if GlobalConfig.logic_name == LogicName.NTEMI else "run = CommandList\\RabbitFX\\Run")
                reset_insert_idx = self._find_mesh_block_reset_insert_index(lines, insert_index)
                if reset_insert_idx != -1:
                    lines[reset_insert_idx:reset_insert_idx] = reset_lines
        mesh_lines_info_phase2 = [(i, self.extract_mesh_name(line)) for i, line in enumerate(lines) if self.extract_mesh_name(line)]
        for mesh_index, mesh_name in reversed(mesh_lines_info_phase2):
            transparency_shader_name, transparency_value = self.extract_transparency_info_from_mesh_name(mesh_name)
            if transparency_shader_name:
                is_new_section = transparency_shader_name not in transparency_sections_to_add
                if is_new_section:
                    transparency_sections_to_add[transparency_shader_name] = [
                        "blend = ADD BLEND_FACTOR INV_BLEND_FACTOR",
                        f"blend_factor[0] = {transparency_value}", f"blend_factor[1] = {transparency_value}",
                        f"blend_factor[2] = {transparency_value}", "blend_factor[3] = 1",
                        "handling = skip",
                        "; --- Start of Overridden Mesh Content ---"
                    ]
                lines.insert(mesh_index + 1, f"run = {transparency_shader_name}")
                start_move_idx = mesh_index + 2
                end_move_idx = -1
                for i in range(start_move_idx, len(lines)):
                    if 'drawindexed' in lines[i]:
                        end_move_idx = i + 1
                        break
                    if '[mesh:' in lines[i] or (lines[i].strip().startswith('[') and not lines[i].strip().startswith('[mesh:')):
                        end_move_idx = i
                        break
                if end_move_idx == -1: end_move_idx = len(lines)
                if start_move_idx < end_move_idx:
                    block_to_move = lines[start_move_idx:end_move_idx]
                    filtered_block_to_move = [
                        line for line in block_to_move
                        if not any(keyword in line for keyword in ["Resource\\RabbitFX\\Glowmap = ref null", r"$\RabbitFX\brightness = 0", "Resource\\RabbitFX\\FXMap = ref null", "Resource\\NTEMIFX\\Glowmap = ref null", r"$\NTEMIFX\brightness = 0", "Resource\\NTEMIFX\\FXMap = ref null"])
                    ]
                    final_block = []
                    for line in filtered_block_to_move:
                        if "run = CommandList\\RabbitFX\\Run" in line or "run = CommandList\\NTEMIFX\\Run" in line:
                            has_resource_before = any(("Resource\\RabbitFX" in prev_line) or ("Resource\\NTEMIFX" in prev_line) for prev_line in final_block)
                            if has_resource_before:
                                final_block.append(line)
                        else:
                            final_block.append(line)
                    if is_new_section:
                        transparency_sections_to_add[transparency_shader_name].extend(final_block)
                    del lines[start_move_idx:end_move_idx]
        return next_swap_key_num

    def execute_postprocess(self, mod_export_path, exporter=None):
        from ..utils.log_utils import LOG as _LOG

        self._ntmi_modimp_extra_ps_t2_diffuse_map = bool(
            getattr(exporter, "extra_ps_t2_diffuse_map", False)
        )

        ini_files = glob.glob(os.path.join(mod_export_path, "*.ini"))
        if not ini_files:
            return

        _LOG.info("🔧 材质转资源节点开始执行")

        total_found = 0
        total_matched = 0

        for ini_file in ini_files:
            self._create_cumulative_backup(ini_file, mod_export_path)

            with open(ini_file, 'r', encoding='utf-8') as f:
                content = f.read()

            preserved_tail_content = ""
            content, preserved_tail_content = self.split_auto_appended_tail_content(content)

            sections = OrderedDict()
            current_section = None
            for line in content.splitlines():
                stripped = line.strip()
                if stripped.startswith('[') and stripped.endswith(']'):
                    current_section = stripped
                    sections[current_section] = []
                elif not stripped:
                    continue
                elif current_section:
                    sections[current_section].append(line)

            sections['_config_path'] = mod_export_path

            transparency_sections_to_add = OrderedDict()
            used_swap_keys = set()
            material_group_to_swapkey = {}
            base_swap_var = self.material_switch_var
            match = re.match(r'(\$\w+)(\d+)', base_swap_var)
            swap_key_prefix = match.group(1) if match else base_swap_var
            next_swap_key_num = int(match.group(2)) if match else 0

            for section_name, lines in list(sections.items()):
                if section_name.startswith('[TextureOverride_') and section_name != '_config_path':
                    next_swap_key_num = self.process_texture_override_section(
                        section_name, sections,
                        material_group_to_swapkey, swap_key_prefix, next_swap_key_num,
                        used_swap_keys, transparency_sections_to_add
                    )

            del sections['_config_path']

            self.define_swapkeys_in_sections(sections, used_swap_keys)

            new_content = []
            for section_name, lines in sections.items():
                new_content.append(section_name)
                new_content.extend(lines)
                new_content.append('')

            if transparency_sections_to_add:
                new_content.append('\n;MARK:CustomShaderTransparency----------------------------------------------------------')
                for shader_name, lines in transparency_sections_to_add.items():
                    new_content.append(f"[{shader_name}]")
                    new_content.extend(lines)
                    new_content.append('')

            if preserved_tail_content:
                new_content.append('')
                new_content.append(preserved_tail_content)

            with open(ini_file, 'w', encoding='utf-8') as f:
                f.write("\n".join(new_content))

        _LOG.info(f"   ✅ 材质转资源节点执行完成")


classes = (
    MaterialPrefixItem,
    DetectedMaterialItem,
    SSMT_OT_MaterialDetectAddPrefix,
    SSMT_OT_MaterialDetectAddCustomPrefix,
    SSMT_OT_MaterialDetectRemovePrefix,
    SSMT_OT_MaterialDetect,
    SSMT_OT_MaterialDetectClear,
    SSMTNode_PostProcess_Material,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
