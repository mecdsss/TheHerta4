import math
import os
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import TypedDict

import bpy
import numpy

from ...common.global_properties import GlobalProterties
from ...common.global_config import GlobalConfig
from ...common.logic_name import LogicName
from ...utils.export_utils import ExportUtils, ObjElementContext, WWMIBufferBuildResult
from ...utils.log_utils import LOG
from ...utils.obj_utils import (
    MergedObject,
    MergedObjectComponent,
    MergedObjectShapeKeys,
    ObjUtils,
    OpenObject,
    TempObject,
    deselect_all_objects,
    get_modifiers,
    remove_vertex_groups,
    select_object,
    set_active_object,
)
from ...utils.shapekey_utils import ShapeKeyUtils
from ...utils.vertexgroup_utils import VertexGroupUtils
from .extracted_object import ExtractedObject, ExtractedObjectHelper
from ...common.buffer_export_helper import BufferExportHelper
from ...common.obj_buffer_helper import ObjBufferHelper
from ...common.workspace_helper import WorkSpaceHelper
from ...common.d3d11_gametype import D3D11GameType
from ...common.texture_metadata_helper import TextureMetadataResolver
from ...blueprint.export_helper import BlueprintExportHelper
from ...blueprint.model import BluePrintModel
from ...common.draw_call_model import DrawCallModel
from ...common.submesh_metadata import SubmeshMetadata, SubmeshMetadataResolver


class BlendRemapEntry(TypedDict):
    forward: list[int]
    reverse: dict[int, int]


@dataclass
class ComponentModel:
    component_name: str
    component_index: int
    final_ordered_draw_obj_model_list: list[DrawCallModel] = field(default_factory=list)


@dataclass
class DrawIBModelWWMI:
    draw_ib: str
    blueprint_model: BluePrintModel

    draw_ib_alias: str = field(init=False, default="")
    primary_submesh_metadata: SubmeshMetadata = field(init=False, repr=False)
    d3d11GameType: D3D11GameType = field(init=False, repr=False)
    extracted_object: ExtractedObject = field(init=False, repr=False)

    ordered_drawcall_model_list: list[DrawCallModel] = field(init=False, default_factory=list, repr=False)
    component_model_list: list[ComponentModel] = field(init=False, default_factory=list, repr=False)
    component_name_component_model_dict: dict[str, ComponentModel] = field(init=False, default_factory=dict, repr=False)

    mesh_vertex_count: int = field(init=False, default=0)
    merged_object: MergedObject | None = field(init=False, default=None, repr=False)
    blend_remap: bool = field(init=False, default=False)
    obj_buffer_model_wwmi: WWMIBufferBuildResult | None = field(init=False, default=None, repr=False)
    blend_remap_maps: dict[str, BlendRemapEntry] = field(init=False, default_factory=dict, repr=False)
    blend_remap_used: dict[str, bool] = field(init=False, default_factory=dict, repr=False)
    component_object_index_dict: dict[str, int] = field(init=False, default_factory=dict, repr=False)
    component_real_vg_count_dict: dict[int, int] = field(init=False, default_factory=dict, repr=False)
    submesh_model_list: list = field(init=False, default_factory=list, repr=False)
    match_first_index_partname_dict: dict[int, str] = field(init=False, default_factory=dict, repr=False)
    submesh_texturemarkinfolist_dict: dict = field(init=False, default_factory=dict, repr=False)
    partname_texturemarkinfolist_dict: dict = field(init=False, default_factory=dict, repr=False)

    blend_remap_forward_buffer: numpy.ndarray | None = field(init=False, default=None, repr=False)
    blend_remap_reverse_buffer: numpy.ndarray | None = field(init=False, default=None, repr=False)
    blend_remap_vertex_vg_buffer: numpy.ndarray | None = field(init=False, default=None, repr=False)

    @staticmethod
    def _get_workspace_submesh_order(draw_ib: str) -> dict[str, int]:
        ordered_unique_str_list: list[str] = []
        candidate_base_paths = [
            GlobalConfig.path_workspace_folder(),
            *WorkSpaceHelper.get_workspace_partition_folderpath_list(),
        ]
        for base_path in candidate_base_paths:
            if not os.path.isdir(base_path):
                continue
            for submesh_folder_path in WorkSpaceHelper._get_submesh_folderpath_list_from(base_path):
                submesh_folder_name = os.path.basename(submesh_folder_path)
                _lod_name, bare_unique_str = WorkSpaceHelper.parse_lod_unique_str(submesh_folder_name)
                if not bare_unique_str.startswith(draw_ib + "-"):
                    continue
                if submesh_folder_name not in ordered_unique_str_list:
                    ordered_unique_str_list.append(submesh_folder_name)
            for lod_name, submesh_folderpath_list in WorkSpaceHelper.get_lod_submesh_folderpath_dict(base_path).items():
                for submesh_folder_path in submesh_folderpath_list:
                    bare_unique_str = os.path.basename(submesh_folder_path)
                    if not bare_unique_str.startswith(draw_ib + "-"):
                        continue
                    unique_str = WorkSpaceHelper._compose_lod_name(lod_name, bare_unique_str)
                    if unique_str not in ordered_unique_str_list:
                        ordered_unique_str_list.append(unique_str)
        return {unique_str: index for index, unique_str in enumerate(ordered_unique_str_list)}

    def __post_init__(self):
        drawib_aliasname_dict: dict[str, str] = WorkSpaceHelper.get_drawib_aliasname_dict()
        self.draw_ib_alias = drawib_aliasname_dict.get(self.draw_ib, self.draw_ib)

        self.ordered_drawcall_model_list = ObjBufferHelper.get_obj_data_model_list_by_draw_ib(
            ordered_draw_obj_data_model_list=self.blueprint_model.ordered_draw_obj_data_model_list,
            draw_ib=self.draw_ib,
        )

        if len(self.ordered_drawcall_model_list) == 0:
            raise ValueError("当前 DrawIB 没有可导出的 DrawCallModel")

        primary_workspace_unique_str = self.ordered_drawcall_model_list[0].get_workspace_unique_str()
        self.primary_submesh_metadata = SubmeshMetadataResolver.resolve(primary_workspace_unique_str)
        self.d3d11GameType = self.primary_submesh_metadata.d3d11_game_type

        self.component_model_list = []
        self.component_name_component_model_dict = {}

        unique_str_metadata_dict: dict[str, SubmeshMetadata] = {
            primary_workspace_unique_str: self.primary_submesh_metadata
        }
        workspace_submesh_order = self._get_workspace_submesh_order(self.draw_ib)
        ordered_workspace_unique_str_list: list[str] = []
        drawcall_model_list_by_unique_str: dict[str, list[DrawCallModel]] = {}
        component_sort_key_by_unique_str: dict[str, tuple[int, int, int]] = {}

        for drawcall_model in self.ordered_drawcall_model_list:
            workspace_unique_str = drawcall_model.get_workspace_unique_str()
            if workspace_unique_str not in ordered_workspace_unique_str_list:
                ordered_workspace_unique_str_list.append(workspace_unique_str)
            drawcall_metadata = unique_str_metadata_dict.get(workspace_unique_str)
            if drawcall_metadata is None:
                drawcall_metadata = SubmeshMetadataResolver.resolve(workspace_unique_str)
                unique_str_metadata_dict[workspace_unique_str] = drawcall_metadata

            try:
                match_first_index = int(drawcall_model.match_first_index)
            except (TypeError, ValueError):
                match_first_index = 0
            component_sort_key_by_unique_str.setdefault(
                workspace_unique_str,
                (
                    workspace_submesh_order.get(workspace_unique_str, 1 << 30),
                    match_first_index,
                    len(component_sort_key_by_unique_str),
                ),
            )
            component_drawcall_model_list = drawcall_model_list_by_unique_str.get(workspace_unique_str, [])
            component_drawcall_model_list.append(drawcall_model)
            drawcall_model_list_by_unique_str[workspace_unique_str] = component_drawcall_model_list

        sorted_workspace_unique_str_list = sorted(
            ordered_workspace_unique_str_list,
            key=lambda unique_str: component_sort_key_by_unique_str.get(unique_str, (1 << 30, 1 << 30)),
        )
        component_index_by_unique_str = {
            unique_str: index + 1
            for index, unique_str in enumerate(sorted_workspace_unique_str_list)
        }

        for workspace_unique_str in sorted_workspace_unique_str_list:
            component_index = component_index_by_unique_str[workspace_unique_str]
            drawcall_metadata = unique_str_metadata_dict.get(workspace_unique_str)
            if drawcall_metadata is None:
                continue
            part_name = drawcall_metadata.part_name or str(component_index)
            component_name = "Component " + str(component_index if not str(part_name).isdigit() else part_name)
            component_drawcall_model_list = drawcall_model_list_by_unique_str.get(workspace_unique_str, [])
            component_model = ComponentModel(
                component_name=component_name,
                component_index=component_index - 1,
                final_ordered_draw_obj_model_list=component_drawcall_model_list,
            )
            self.component_model_list.append(component_model)
            self.component_name_component_model_dict[component_model.component_name] = component_model

        ordered_metadata = [
            unique_str_metadata_dict[workspace_unique_str]
            for workspace_unique_str in sorted_workspace_unique_str_list
            if workspace_unique_str in unique_str_metadata_dict
        ]
        self.extracted_object = ExtractedObjectHelper.build_from_submesh_metadata_list(ordered_metadata)

        LOG.newline()

        self.merged_object = self.build_merged_object(extracted_object=self.extracted_object)

        obj_name_temp_object_dict: dict[str, TempObject] = {}
        for component in self.merged_object.components:
            for temp_object in component.objects:
                obj_name_temp_object_dict[temp_object.name] = temp_object

        for component_model in self.component_model_list:
            updated_drawcall_model_list: list[DrawCallModel] = []
            for drawcall_model in component_model.final_ordered_draw_obj_model_list:
                temp_object = obj_name_temp_object_dict.get(drawcall_model.obj_name)
                if temp_object is not None:
                    drawcall_model.index_count = temp_object.index_count
                    drawcall_model.index_offset = temp_object.index_offset
                    drawcall_model.vertex_count = temp_object.vertex_count
                updated_drawcall_model_list.append(drawcall_model)
            component_model.final_ordered_draw_obj_model_list = updated_drawcall_model_list
            self.component_name_component_model_dict[component_model.component_name] = component_model

        self.submesh_model_list = []
        self.match_first_index_partname_dict = {}
        seen_submesh_keys:set[tuple[str, int]] = set()
        sorted_drawcall_model_list = sorted(
            self.ordered_drawcall_model_list,
            key=lambda drawcall_model: (
                workspace_submesh_order.get(drawcall_model.get_workspace_unique_str(), 1 << 30),
                int(drawcall_model.match_first_index) if str(drawcall_model.match_first_index).isdigit() else 0,
            ),
        )
        for drawcall_model in sorted_drawcall_model_list:
            workspace_unique_str = drawcall_model.get_workspace_unique_str()
            drawcall_metadata = unique_str_metadata_dict.get(workspace_unique_str)
            if drawcall_metadata is None:
                continue

            try:
                match_first_index = int(drawcall_model.match_first_index)
            except (TypeError, ValueError):
                match_first_index = 0

            submesh_key = (workspace_unique_str, match_first_index)
            if submesh_key in seen_submesh_keys:
                continue
            seen_submesh_keys.add(submesh_key)

            part_name = drawcall_metadata.part_name or str(len(seen_submesh_keys))
            self.submesh_model_list.append(SimpleNamespace(
                unique_str=workspace_unique_str,
                workspace_unique_str=workspace_unique_str,
                match_first_index=match_first_index,
                d3d11_game_type=drawcall_metadata.d3d11_game_type,
            ))
            self.match_first_index_partname_dict[match_first_index] = part_name

        if self.submesh_model_list:
            self.submesh_texturemarkinfolist_dict = TextureMetadataResolver.load_submesh_texture_markup_info_from_all_submeshes(draw_ib_model=self)
            self.partname_texturemarkinfolist_dict = TextureMetadataResolver.load_texture_markup_info_from_all_submeshes(draw_ib_model=self)

        ObjBufferHelper.check_and_verify_attributes(obj=self.merged_object.object, d3d11_game_type=self.d3d11GameType)

        element_context = ExportUtils.build_obj_element_context(
            d3d11_game_type=self.d3d11GameType,
            obj=self.merged_object.object,
        )

        if self.blend_remap:
            self.replace_remapped_blendindices(element_context)

        element_context.element_vertex_ndarray = ObjBufferHelper.convert_to_element_vertex_ndarray(
            mesh=element_context.mesh,
            original_elementname_data_dict=element_context.original_elementname_data_dict,
            final_elementname_data_dict=element_context.final_elementname_data_dict,
            d3d11_game_type=self.d3d11GameType,
        )

        self.obj_buffer_model_wwmi = ExportUtils.build_wwmi_obj_buffer_result(element_context)

        position_stride: int = self.d3d11GameType.CategoryStrideDict["Position"]
        position_bytelength: int = len(self.obj_buffer_model_wwmi.category_buffer_dict["Position"])
        self.mesh_vertex_count = int(position_bytelength / position_stride)

        if self.blend_remap:
            self.blend_remap_vertex_vg_buffer = self._build_blend_remap_vertex_vg_buffer(element_context)

        bpy.data.objects.remove(self.merged_object.object, do_unlink=True)

    def _build_blend_remap_vertex_vg_buffer(self, element_context: ObjElementContext) -> numpy.ndarray | None:
        index_vertex_id_dict = self.obj_buffer_model_wwmi.index_vertex_id_dict
        if not index_vertex_id_dict:
            return None

        original_blendindices = element_context.original_elementname_data_dict.get("BLENDINDICES")
        unique_first_loop_indices = getattr(self.obj_buffer_model_wwmi, "unique_first_loop_indices", None)
        if original_blendindices is None or unique_first_loop_indices is None:
            return None

        num_vgs = self.d3d11GameType.get_blendindices_count_wwmi()
        vg_array = numpy.zeros((len(index_vertex_id_dict), num_vgs), dtype=numpy.uint16)

        sampled_blendindices = original_blendindices[unique_first_loop_indices]
        if getattr(sampled_blendindices, "ndim", 1) == 1:
            sampled_blendindices = sampled_blendindices.reshape(-1, 1)

        for index in range(min(num_vgs, sampled_blendindices.shape[1])):
            vg_array[:, index] = sampled_blendindices[:, index].astype(numpy.uint16)

        return vg_array

    def write_buffer_files(self):
        if self.obj_buffer_model_wwmi is None:
            return

        BufferExportHelper.write_buf_ib_r32_uint(self.obj_buffer_model_wwmi.ib, self.draw_ib + "-Component1.buf")
        BufferExportHelper.write_category_buffer_files(self.obj_buffer_model_wwmi.category_buffer_dict, self.draw_ib)

        # 直出基础轮次会跳过 ShapeKey 资源写盘，交给后面的直出生成器统一落盘。
        if (
            self.obj_buffer_model_wwmi.export_shapekey
            and not BlueprintExportHelper.should_suppress_shapekey_resource_export()
        ):
            BufferExportHelper.write_buf_shapekey_offsets(self.obj_buffer_model_wwmi.shapekey_offsets, self.draw_ib + "-ShapeKeyOffset.buf")
            BufferExportHelper.write_buf_shapekey_vertex_ids(self.obj_buffer_model_wwmi.shapekey_vertex_ids, self.draw_ib + "-ShapeKeyVertexId.buf")
            BufferExportHelper.write_buf_shapekey_vertex_offsets(self.obj_buffer_model_wwmi.shapekey_vertex_offsets, self.draw_ib + "-ShapeKeyVertexOffset.buf")

        if self.blend_remap_forward_buffer is not None and self.blend_remap_forward_buffer.size != 0:
            BufferExportHelper.write_buf_blendindices_uint16(self.blend_remap_forward_buffer, self.draw_ib + "-BlendRemapForward.buf")

        if self.blend_remap_reverse_buffer is not None and self.blend_remap_reverse_buffer.size != 0:
            BufferExportHelper.write_buf_blendindices_uint16(self.blend_remap_reverse_buffer, self.draw_ib + "-BlendRemapReverse.buf")

        if self.blend_remap_vertex_vg_buffer is not None and self.blend_remap_vertex_vg_buffer.size != 0:
            BufferExportHelper.write_buf_blendindices_uint16(self.blend_remap_vertex_vg_buffer, self.draw_ib + "-BlendRemapVertexVG.buf")

    def _should_duplicate_source_for_merge(self, source_obj: bpy.types.Object) -> bool:
        """决定合并前是否需要再复制一份临时物体。

        非多文件导出时，蓝图节点已经被重定向到前处理阶段生成的 _copy 副本，
        这些副本会在轮次结束后统一清理，可以直接作为破坏性 join 的输入，
        避免再复制一次 TEMP_* 物体。

        多文件导出保留复制策略，避免同一轮里预处理副本被过早消耗后影响
        多文件节点对象列表的后续使用或调试排查。
        """

        if source_obj is None:
            return True

        if self.blueprint_model.multi_file_export_nodes:
            return True

        if BlueprintExportHelper.should_preserve_current_shapekey_mix_for_export():
            return True

        return not source_obj.name.endswith('_copy')

    @staticmethod
    def _append_candidate_name(candidate_names: list[str], name: str):
        clean_name = str(name or "").strip()
        if clean_name and clean_name not in candidate_names:
            candidate_names.append(clean_name)

    def _resolve_source_object(self, drawcall_model: DrawCallModel) -> tuple[str, bpy.types.Object | None, list[str]]:
        candidate_names: list[str] = []
        for candidate_name in (
            drawcall_model.get_blender_obj_name(),
            getattr(drawcall_model, "source_obj_name", "") or "",
            getattr(drawcall_model, "obj_name", "") or "",
        ):
            self._append_candidate_name(candidate_names, candidate_name)

            mapped_name = BluePrintModel.get_mapped_object_name(candidate_name)
            if mapped_name != candidate_name:
                self._append_candidate_name(candidate_names, mapped_name)

        for candidate_name in candidate_names:
            source_obj = ObjUtils.get_obj_by_name(candidate_name)
            if source_obj is not None:
                return candidate_name, source_obj, candidate_names

        return "", None, candidate_names

    def build_merged_object(self, extracted_object: ExtractedObject) -> MergedObject:
        components: list[MergedObjectComponent] = []
        for _component in extracted_object.components:
            components.append(MergedObjectComponent(objects=[], index_count=0))

        workspace_collection = bpy.context.collection
        processed_obj_name_list: list[str] = []

        for component_model in self.component_model_list:
            component_id = int(component_model.component_index)

            for drawcall_model in component_model.final_ordered_draw_obj_model_list:
                export_obj_name = drawcall_model.obj_name
                if export_obj_name in processed_obj_name_list:
                    continue

                processed_obj_name_list.append(export_obj_name)

                source_obj_name, source_obj, tried_names = self._resolve_source_object(drawcall_model)
                if source_obj is None:
                    raise ValueError(
                        "WWMI 导出找不到用于合并的 Blender 物体: "
                        f"导出名='{export_obj_name}', "
                        f"候选名={tried_names or ['<empty>']}"
                    )

                if self._should_duplicate_source_for_merge(source_obj):
                    temp_obj = ObjUtils.copy_object(
                        bpy.context,
                        source_obj,
                        name=f"TEMP_{source_obj.name}",
                        collection=workspace_collection,
                    )
                else:
                    temp_obj = source_obj

                components[component_id].objects.append(
                    TempObject(
                        name=export_obj_name or source_obj_name,
                        object=temp_obj,
                    )
                )

        self.component_real_vg_count_dict = {}
        self.component_object_index_dict = {}
        index_offset = 0

        for component_id, component in enumerate(components):
            for temp_object in component.objects:
                temp_obj = temp_object.object

                if GlobalProterties.ignore_muted_shape_keys() and temp_obj.data.shape_keys:
                    muted_shape_keys = []
                    for shapekey_id in range(len(temp_obj.data.shape_keys.key_blocks)):
                        shape_key = temp_obj.data.shape_keys.key_blocks[shapekey_id]
                        if shape_key.mute:
                            muted_shape_keys.append(shape_key)
                    for shape_key in muted_shape_keys:
                        temp_obj.shape_key_remove(shape_key)

                if GlobalProterties.apply_all_modifiers():
                    with OpenObject(bpy.context, temp_obj) as opened_obj:
                        selected_modifiers = [modifier.name for modifier in get_modifiers(opened_obj)]
                        ShapeKeyUtils.apply_modifiers_for_object_with_shape_keys(bpy.context, selected_modifiers, None)

                ObjUtils.triangulate_object(bpy.context, temp_obj)

                vertex_groups = ObjUtils.get_vertex_groups(temp_obj)
                if GlobalProterties.import_merged_vgmap():
                    total_vg_count = max((extracted_component.vg_count for extracted_component in extracted_object.components), default=0)
                    ignore_list = [
                        vertex_group
                        for vertex_group in vertex_groups
                        if "ignore" in vertex_group.name.lower() or vertex_group.index >= total_vg_count
                    ]
                else:
                    extracted_component = extracted_object.components[component_id]
                    total_vg_count = len(extracted_component.vg_map)
                    ignore_list = [
                        vertex_group
                        for vertex_group in vertex_groups
                        if "ignore" in vertex_group.name.lower() or vertex_group.index >= total_vg_count
                    ]
                remove_vertex_groups(temp_obj, ignore_list)

                temp_object.vertex_count = len(temp_obj.data.vertices)
                temp_object.index_count = len(temp_obj.data.polygons) * 3
                temp_object.index_offset = index_offset
                index_offset += temp_object.index_count
                component.vertex_count += temp_object.vertex_count
                component.index_count += temp_object.index_count

        drawib_merged_object: list[bpy.types.Object] = []
        drawib_vertex_count: int = 0
        drawib_index_count: int = 0
        component_obj_list: list[bpy.types.Object] = []

        for component_index, component in enumerate(components):
            component_merged_object = [temp_object.object for temp_object in component.objects]

            if len(component_merged_object) == 0:
                continue

            ObjUtils.join_objects(bpy.context, component_merged_object)
            component_obj = component_merged_object[0]

            if GlobalConfig.logic_name == LogicName.WWMI or GlobalConfig.logic_name == LogicName.NTEMI:
                ObjUtils.select_obj(component_obj)
                component_obj.rotation_euler[0] = 0
                component_obj.rotation_euler[1] = 0
                component_obj.rotation_euler[2] = math.radians(180)
                component_obj.scale = (100, 100, 100)
                # WWMI/NTEMI 的组件缩放会影响 ShapeKey 顶点位置，这里必须走保 ShapeKey 的变换应用。
                ShapeKeyUtils.transform_apply_preserve_shape_keys(component_obj, location=False, rotation=True, scale=True)

            if GlobalProterties.export_add_missing_vertex_groups():
                ObjUtils.select_obj(component_obj)
                VertexGroupUtils.fill_vertex_group_gaps()
                component_obj.select_set(False)

            component.remap_key_name = component_obj.name
            self.component_object_index_dict[component_obj.name] = component_index
            component_obj_list.append(component_obj)
            drawib_merged_object.append(component_obj)

            used_vg_indices = set()
            for vertex in component_obj.data.vertices:
                for group in vertex.groups:
                    if group.weight > 0.0:
                        used_vg_indices.add(group.group)
            self.component_real_vg_count_dict[component_index] = len(used_vg_indices)

            drawib_vertex_count += component.vertex_count
            drawib_index_count += component.index_count

        self.export_blendremap_forward_and_reverse(component_obj_list)

        if drawib_merged_object:
            bpy.ops.object.select_all(action='DESELECT')
            active_object = drawib_merged_object[0]
            active_object.select_set(True)
            bpy.context.view_layer.objects.active = active_object

        ObjUtils.join_objects(bpy.context, drawib_merged_object)
        merged_obj = drawib_merged_object[0]
        ObjUtils.rename_object(merged_obj, "TEMP_EXPORT_OBJECT")

        if GlobalProterties.export_add_missing_vertex_groups():
            ObjUtils.select_obj(merged_obj)
            VertexGroupUtils.merge_vertex_groups_with_same_number_v2()
            merged_obj.select_set(False)

        deselect_all_objects()
        select_object(merged_obj)
        set_active_object(bpy.context, merged_obj)

        mesh = ObjUtils.get_mesh_evaluate_from_obj(merged_obj)
        merged_object = MergedObject(
            object=merged_obj,
            mesh=mesh,
            components=components,
            vertex_count=len(merged_obj.data.vertices),
            index_count=len(merged_obj.data.polygons) * 3,
            vg_count=len(ObjUtils.get_vertex_groups(merged_obj)),
            shapekeys=MergedObjectShapeKeys(),
        )

        if drawib_vertex_count != merged_object.vertex_count:
            raise ValueError("vertex_count mismatch between merged object and its components")

        if drawib_index_count != merged_object.index_count:
            raise ValueError("index_count mismatch between merged object and its components")

        LOG.newline()
        return merged_object

    def export_blendremap_forward_and_reverse(self, component_objects: list[bpy.types.Object]):
        num_vgs = self.d3d11GameType.get_blendindices_count_wwmi()

        blend_remap_forward: numpy.ndarray = numpy.empty(0, dtype=numpy.uint16)
        blend_remap_reverse: numpy.ndarray = numpy.empty(0, dtype=numpy.uint16)
        remap_maps: dict[str, BlendRemapEntry] = {}
        remap_used: dict[str, bool] = {}

        for component_obj in component_objects:
            used_vg_set: set[int] = set()

            for vertex in component_obj.data.vertices:
                groups = [(group.group, group.weight) for group in vertex.groups]
                if len(groups) == 0:
                    continue

                groups.sort(key=lambda item: item[1], reverse=True)
                for group_index, weight in groups[:num_vgs]:
                    if weight > 0:
                        used_vg_set.add(int(group_index))

            max_used = max(used_vg_set) if len(used_vg_set) else 0
            if len(used_vg_set) == 0 or max_used < 256:
                remap_maps[component_obj.name] = {"forward": [], "reverse": {}}
                remap_used[component_obj.name] = False
                continue

            self.blend_remap = True

            obj_vg_ids = numpy.array(sorted(used_vg_set), dtype=numpy.uint16)
            forward = numpy.zeros(512, dtype=numpy.uint16)
            forward[:len(obj_vg_ids)] = obj_vg_ids

            reverse = numpy.zeros(512, dtype=numpy.uint16)
            reverse[obj_vg_ids] = numpy.arange(len(obj_vg_ids), dtype=numpy.uint16)

            blend_remap_forward = numpy.concatenate((blend_remap_forward, forward), axis=0)
            blend_remap_reverse = numpy.concatenate((blend_remap_reverse, reverse), axis=0)

            forward_list = [int(value) for value in obj_vg_ids.tolist()]
            reverse_map: dict[int, int] = {int(value): int(index) for index, value in enumerate(forward_list)}
            remap_maps[component_obj.name] = {"forward": forward_list, "reverse": reverse_map}
            remap_used[component_obj.name] = True

        self.blend_remap_maps = remap_maps
        self.blend_remap_used = remap_used
        self.blend_remap_forward_buffer = blend_remap_forward
        self.blend_remap_reverse_buffer = blend_remap_reverse

    def replace_remapped_blendindices(self, element_context: ObjElementContext):
        if not hasattr(self, "blend_remap_maps") or not self.blend_remap_maps:
            return

        mesh = element_context.mesh
        loops_len = len(mesh.loops)

        loop_to_poly = numpy.empty(loops_len, dtype=numpy.int32)
        for poly in mesh.polygons:
            start = poly.loop_start
            end = start + poly.loop_total
            loop_to_poly[start:end] = poly.index

        arr: numpy.ndarray | None = None
        if "BLENDINDICES" in getattr(element_context, "original_elementname_data_dict", {}):
            arr = element_context.original_elementname_data_dict["BLENDINDICES"].copy()
        elif element_context.element_vertex_ndarray is not None and "BLENDINDICES" in element_context.element_vertex_ndarray.dtype.names:
            arr = element_context.element_vertex_ndarray["BLENDINDICES"].copy()

        if arr is None:
            return

        poly_count = len(mesh.polygons)
        polygon_to_objname: list[str | None] = [None] * poly_count

        for component in self.merged_object.components:
            component_remap_key_name = getattr(component, "remap_key_name", None)
            for temp_obj in component.objects:
                if not hasattr(temp_obj, "index_offset") or not hasattr(temp_obj, "index_count"):
                    continue
                poly_start = int(temp_obj.index_offset // 3)
                poly_end = poly_start + int(temp_obj.index_count // 3)
                for poly_index in range(poly_start, poly_end):
                    if 0 <= poly_index < poly_count:
                        polygon_to_objname[poly_index] = component_remap_key_name or temp_obj.name

        width = 1 if getattr(arr, "ndim", 1) == 1 else arr.shape[1]

        for loop_index in range(loops_len):
            poly_idx = int(loop_to_poly[loop_index])
            component_obj_name = polygon_to_objname[poly_idx] if 0 <= poly_idx < len(polygon_to_objname) else None
            if not component_obj_name:
                continue
            remap_entry = self.blend_remap_maps.get(component_obj_name)
            if not remap_entry:
                continue
            reverse_map = remap_entry.get("reverse", {})

            if width == 1:
                original_value = int(arr[loop_index])
                arr[loop_index] = reverse_map.get(original_value, original_value)
            else:
                for value_index in range(width):
                    original_value = int(arr[loop_index, value_index])
                    arr[loop_index, value_index] = reverse_map.get(original_value, original_value)

        element_context.final_elementname_data_dict["BLENDINDICES"] = arr

    def get_part_name_by_match_first_index(self, match_first_index):
        try:
            return self.match_first_index_partname_dict.get(int(match_first_index))
        except (TypeError, ValueError):
            return None

    @property
    def part_name_submesh_dict(self) -> dict[str, object]:
        part_name_submesh = {}
        for submesh_model in self.submesh_model_list:
            part_name = self.get_submesh_part_name(submesh_model)
            if part_name and part_name not in part_name_submesh:
                part_name_submesh[part_name] = submesh_model
        return part_name_submesh

    def get_submesh_part_name(self, submesh_model):
        return self.get_part_name_by_match_first_index(getattr(submesh_model, "match_first_index", 0))

    def get_submesh_texture_markup_info_list(self, submesh_model):
        unique_str = getattr(submesh_model, "unique_str", "")
        texture_markup_info_list = self.submesh_texturemarkinfolist_dict.get(unique_str)
        if texture_markup_info_list is not None:
            return texture_markup_info_list

        workspace_unique_str = getattr(submesh_model, "workspace_unique_str", "")
        if workspace_unique_str:
            texture_markup_info_list = self.submesh_texturemarkinfolist_dict.get(workspace_unique_str)
            if texture_markup_info_list is not None:
                return texture_markup_info_list

        part_name = self.get_submesh_part_name(submesh_model)
        if part_name is None:
            return []
        return self.partname_texturemarkinfolist_dict.get(part_name, [])
