import bpy
import os
import time
from bpy.types import NodeTree, Node, NodeSocket

from ..common.logic_name import LogicName
from ..common.global_config import GlobalConfig
from ..common.global_properties import GlobalProterties
from ..common.object_prefix_helper import ObjectPrefixHelper
from .node_base import SSMTBlueprintTree, SSMTNodeBase

BLENDER_VERSION = bpy.app.version[:2]

_picking_node_name = None
_picking_tree_name = None
_is_viewing_group_objects = False
_PICK_OBJECT_TIMEOUT_SECONDS = 30.0



class SSMT_OT_RefreshNodeObjectIDs(bpy.types.Operator):
    '''刷新节点树中所有节点的物体ID关联'''
    bl_idname = "ssmt.refresh_node_object_ids"
    bl_label = "刷新物体ID关联"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        updated_count = 0
        
        for tree in bpy.data.node_groups:
            if tree.bl_idname == 'SSMTBlueprintTreeType':
                for node in tree.nodes:
                    if node.bl_idname == 'SSMTNode_Object_Info':
                        obj_name = getattr(node, 'object_name', '')
                        obj_id = getattr(node, 'object_id', '')
                        
                        if obj_name:
                            obj = bpy.data.objects.get(obj_name)
                            if obj:
                                new_obj_id = str(obj.as_pointer())
                                if node.object_id != new_obj_id:
                                    node.object_id = new_obj_id
                                    updated_count += 1
                            elif obj_id:
                                node.object_id = ""
                                updated_count += 1
                    
                    elif node.bl_idname == 'SSMTNode_MultiFile_Export':
                        for item in node.object_list:
                            obj_name = getattr(item, 'object_name', '')
                            if obj_name:
                                obj = bpy.data.objects.get(obj_name)
                                if obj:
                                    new_name = obj.name
                                    new_obj_id = str(obj.as_pointer())
                                    if item.object_name != new_name:
                                        item.object_name = new_name
                                        updated_count += 1
                                    if getattr(item, 'object_id', '') != new_obj_id:
                                        item.object_id = new_obj_id
                                        updated_count += 1
                                elif getattr(item, 'original_object_name', ''):
                                    orig_obj = bpy.data.objects.get(item.original_object_name)
                                    if orig_obj:
                                        item.object_name = item.original_object_name
                                        item.object_id = str(orig_obj.as_pointer())
                                        updated_count += 1
        
        if updated_count > 0:
            self.report({'INFO'}, f"已更新 {updated_count} 个节点的物体引用")
           
        else:
            self.report({'INFO'}, "所有节点都已建立物体引用关联")
        
        return {'FINISHED'}


class SSMT_OT_SelectNodeObject(bpy.types.Operator):
    '''Select this object in 3D View'''
    bl_idname = "ssmt.select_node_object"
    bl_label = "Select Object"
    
    object_name: bpy.props.StringProperty()

    def execute(self, context):
        obj_name = self.object_name
        if not obj_name:
            return {'CANCELLED'}
        
        obj = bpy.data.objects.get(obj_name)
        if obj:
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except:
                pass
                
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({'INFO'}, f"Selected: {obj_name}")
        else:
            self.report({'WARNING'}, f"Object '{obj_name}' not found")
        
        return {'FINISHED'}


class SSMT_OT_StartPickObject(bpy.types.Operator):
    '''Start picking an object from 3D View'''
    bl_idname = "ssmt.start_pick_object"
    bl_label = "Pick Object"
    bl_description = "点击后在3D视图中选择一个物体"
    
    node_name: bpy.props.StringProperty()
    
    def execute(self, context):
        global _picking_node_name, _picking_tree_name
        
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        
        if not tree:
            self.report({'WARNING'}, "无法获取节点树上下文")
            return {'CANCELLED'}
        
        _picking_node_name = self.node_name
        _picking_tree_name = tree.name
        self.report({'INFO'}, "请在3D视图中点击选择一个物体")
        
        bpy.ops.ssmt.pick_object_modal('INVOKE_DEFAULT')
        
        return {'FINISHED'}


class SSMT_OT_PickObjectModal(bpy.types.Operator):
    '''Modal operator for picking objects in 3D View'''
    bl_idname = "ssmt.pick_object_modal"
    bl_label = "Pick Object"
    bl_options = {'REGISTER', 'INTERNAL'}

    def _finish_picking(self, context, status, clear_globals=True):
        global _picking_node_name, _picking_tree_name

        timer = getattr(self, "_timer", None)
        if timer is not None:
            context.window_manager.event_timer_remove(timer)
            self._timer = None

        if clear_globals:
            _picking_node_name = None
            _picking_tree_name = None

        return status

    def _get_current_selected_object(self, context):
        active_obj = getattr(context.view_layer.objects, "active", None)
        if active_obj and active_obj in context.selected_objects:
            return active_obj

        if context.selected_objects:
            return context.selected_objects[0]

        return None

    def _try_apply_selected_object(self, context):
        global _picking_node_name, _picking_tree_name

        current_obj = self._get_current_selected_object(context)
        if current_obj is None:
            return None

        if current_obj == self._last_selected_obj and current_obj in self._initial_selected_objs:
            return None

        tree = bpy.data.node_groups.get(_picking_tree_name)
        if tree is None:
            self.report({'WARNING'}, "节点树已失效，已取消吸管选择")
            return self._finish_picking(context, {'CANCELLED'})

        node = tree.nodes.get(_picking_node_name)
        if node is None:
            self.report({'WARNING'}, "目标节点已不存在，已取消吸管选择")
            return self._finish_picking(context, {'CANCELLED'})

        node.object_name = current_obj.name
        self.report({'INFO'}, f"已选择物体: {current_obj.name}")
        return self._finish_picking(context, {'FINISHED'})
    
    def invoke(self, context, event):
        global _picking_node_name
        
        if not _picking_node_name:
            return {'CANCELLED'}
        
        self._initial_selected_objs = set(context.selected_objects)
        self._last_selected_obj = self._get_current_selected_object(context)
        self._started_at = time.monotonic()
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        global _picking_node_name, _picking_tree_name

        if not _picking_node_name or not _picking_tree_name:
            return self._finish_picking(context, {'CANCELLED'}, clear_globals=False)

        if time.monotonic() - self._started_at > _PICK_OBJECT_TIMEOUT_SECONDS:
            self.report({'WARNING'}, "吸管选择超时，已自动取消")
            return self._finish_picking(context, {'CANCELLED'})
        
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            return self._finish_picking(context, {'CANCELLED'})

        if event.type == 'TIMER':
            result = self._try_apply_selected_object(context)
            if result is not None:
                return result
            return {'RUNNING_MODAL'}

        if event.type in {
            'LEFTMOUSE',
            'MIDDLEMOUSE',
            'MOUSEMOVE',
            'WHEELUPMOUSE',
            'WHEELDOWNMOUSE',
            'TRACKPADPAN',
            'TRACKPADZOOM',
        }:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}


class SSMT_OT_SelectGenerateModFolder(bpy.types.Operator):
    '''选择 Generate Mod 输出目录'''
    bl_idname = "ssmt.select_generate_mod_folder"
    bl_label = "选择 Generate Mod 输出目录"
    bl_options = {'REGISTER', 'INTERNAL'}

    directory: bpy.props.StringProperty(subtype='DIR_PATH')

    def invoke(self, context, event):
        current_dir = context.scene.global_properties.generate_mod_folder_path
        if current_dir:
            self.directory = bpy.path.abspath(current_dir)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        selected_dir = bpy.path.abspath(self.directory).strip()
        if not selected_dir:
            self.report({'WARNING'}, "未选择输出目录")
            return {'CANCELLED'}

        context.scene.global_properties.generate_mod_folder_path = os.path.normpath(selected_dir)
        return {'FINISHED'}


def draw_view3d_header(self, context):
    global _picking_node_name
    if _picking_node_name:
        self.layout.label(text="请在3D视图中点击选择一个物体...", icon='EYEDROPPER')


class SSMTNode_Object_Info(SSMTNodeBase):
    '''Object Info Node'''
    bl_idname = 'SSMTNode_Object_Info'
    bl_label = 'Object Info'
    bl_icon = 'OBJECT_DATAMODE'
    bl_width_min = 300

    def _set_cached_prefix_data(self, prefix: str, separator: str):
        self["object_prefix"] = ObjectPrefixHelper.normalize_prefix(prefix)
        self["prefix_separator"] = separator or "."

    def _refresh_prefix_cache(self, from_prefix_update: bool = False):
        self.label = self.object_name if self.object_name else "Object Info"

        prefix_info = ObjectPrefixHelper.get_node_prefix_info(self)
        prefix = ""
        separator = self.prefix_separator or "."
        if prefix_info:
            prefix, separator = prefix_info

        if prefix:
            self._set_cached_prefix_data(prefix, separator)
            if not from_prefix_update:
                normalized = ObjectPrefixHelper.normalize_prefix(prefix)
                if self.object_prefix != normalized:
                    self.object_prefix = normalized
        elif not self.object_prefix:
            self["prefix_separator"] = separator

        parts = ObjectPrefixHelper.parse_prefix_parts(self.object_prefix)
        self.draw_ib = parts["draw_ib"]
        self.index_count = parts["index_count"]
        self.first_index = parts["first_index"]
        self.component = parts["component"]

        _, _, base_name = ObjectPrefixHelper.split_name_and_prefix(self.object_name, self.object_prefix, self.prefix_separator)
        self.alias_name = base_name

        obj = bpy.data.objects.get(self.object_name)
        if obj:
            self.object_id = str(obj.as_pointer())
        elif not self.object_name:
            self.object_id = ""

        self.update_node_width([self.object_name, self.object_prefix])

    def update_object_prefix(self, context):
        self._set_cached_prefix_data(self.object_prefix, self.prefix_separator)
        self._refresh_prefix_cache(from_prefix_update=True)
    
    def update_object_name(self, context):
        self._refresh_prefix_cache()
    object_name: bpy.props.StringProperty(name="Object Name", default="", update=update_object_name)
    object_id: bpy.props.StringProperty(name="Object ID", default="")
    original_object_name: bpy.props.StringProperty(name="Original Object Name", default="")
    object_prefix: bpy.props.StringProperty(name="Prefix", default="", update=update_object_prefix)
    prefix_separator: bpy.props.StringProperty(name="Prefix Separator", default=".")


    draw_ib: bpy.props.StringProperty(name="DrawIB", default="")
    index_count: bpy.props.StringProperty(name="IndexCount", default="")
    first_index: bpy.props.StringProperty(name="FirstIndex", default="")
    component: bpy.props.StringProperty(name="Component", default="")
    alias_name: bpy.props.StringProperty(name="Alias Name", default="")

    def get_effective_prefix(self) -> str:
        prefix_info = ObjectPrefixHelper.get_node_prefix_info(self)
        return prefix_info[0] if prefix_info else ""

    def get_effective_separator(self) -> str:
        prefix_info = ObjectPrefixHelper.get_node_prefix_info(self)
        return prefix_info[1] if prefix_info else (self.prefix_separator or ".")

    def get_virtual_object_name(self) -> str:
        return ObjectPrefixHelper.build_virtual_object_name_for_node(self)

    def init(self, context):
        self.outputs.new('SSMTSocketObject', "Object")

    def draw_buttons(self, context, layout):
        row = layout.row(align=True)

        row.prop_search(self, "object_name", bpy.data, "objects", text="", icon='OBJECT_DATA')
        
        op = row.operator("ssmt.start_pick_object", text="", icon='EYEDROPPER')
        op.node_name = self.name

        if self.object_name:
            obj = bpy.data.objects.get(self.object_name)
            if obj:
                if obj.type != 'MESH':
                    row.label(text="", icon='ERROR')
                    layout.label(text="错误: 仅支持网格物体", icon='ERROR')
                else:
                    op = row.operator("ssmt.select_node_object", text="", icon='RESTRICT_SELECT_OFF')
                    op.object_name = self.object_name
                    
                    if not self.object_id:
                        self.object_id = str(obj.as_pointer())
            else:
                row.label(text="", icon='ERROR')

        row = layout.row(align=True)
        row.enabled = False
        row.prop(self, "object_prefix", text="前缀")


class SSMTNode_Object_Group(SSMTNodeBase):
    '''单纯用于分组的节点，可以接受任何节点作为输入，放在一个组里'''
    bl_idname = 'SSMTNode_Object_Group'
    bl_label = 'Group'
    bl_icon = 'GROUP'

    def init(self, context):
        self.inputs.new('SSMTSocketObject', "Input 1")
        self.outputs.new('SSMTSocketObject', "Output")
        self.width = 200

    def draw_buttons(self, context, layout):
        layout.operator("ssmt.view_group_objects", text="查看递归解析预览", icon='HIDE_OFF').node_name = self.name

    def update(self):
        if self.inputs and self.inputs[-1].is_linked:
            self.inputs.new('SSMTSocketObject', f"Input {len(self.inputs) + 1}")
        
        if len(self.inputs) > 1 and not self.inputs[-1].is_linked and not self.inputs[-2].is_linked:
             self.inputs.remove(self.inputs[-1])


class SSMTNode_Result_Output(SSMTNodeBase):
    '''Result Output Node'''
    bl_idname = 'SSMTNode_Result_Output'
    bl_label = 'Generate Mod'
    bl_icon = 'EXPORT'

    show_vertex_deduplication_panel: bpy.props.BoolProperty(
        name="顶点去重精度控制",
        default=False,
    ) # type: ignore

    def init(self, context):
        self.inputs.new('SSMTSocketObject', "Group 1")
        self.outputs.new('SSMTSocketPostProcess', "Post Process")
        self.width = 400

    def draw_buttons(self, context, layout):
        layout.operator("ssmt.generate_mod_blueprint", text="Generate Mod", icon='EXPORT')
        
        if GlobalConfig.logic_name == LogicName.WWMI:
            layout.prop(context.scene.global_properties, "ignore_muted_shape_keys")
            layout.prop(context.scene.global_properties, "apply_all_modifiers")
            layout.prop(context.scene.global_properties, "export_add_missing_vertex_groups")

        layout.prop(context.scene.global_properties, 
                    "forbid_auto_texture_ini",text="禁止自动贴图流程")

        if GlobalConfig.logic_name != LogicName.GF2:
            layout.prop(context.scene.global_properties,
                        "recalculate_tangent",text="向量归一化法线存入TANGENT(全局)")

        if GlobalConfig.logic_name == LogicName.HIMI:
            layout.prop(context.scene.global_properties,
                        "recalculate_color",text="算术平均归一化法线存入COLOR(全局)")

        if LogicName.is_zzmi_family(GlobalConfig.logic_name):
            layout.prop(context.scene.global_properties, "zzz_use_slot_fix")

        if GlobalConfig.logic_name == LogicName.GIMI:
            layout.prop(context.scene.global_properties, "gimi_use_orfix")

        if GlobalConfig.logic_name == LogicName.EFMI:
            layout.prop(context.scene.global_properties, "use_rabbitfx_slot")

        from .export_helper import BlueprintExportHelper
        has_mod_panel_node = BlueprintExportHelper.has_mod_panel_node(tree=self.id_data)
        info_box = layout.box()
        if has_mod_panel_node:
            info_box.label(text="已检测到 Mod面板 节点，导出时会生成分支 Mod 面板", icon='MENU_PANEL')
        else:
            info_box.label(text="如需生成分支 Mod 面板，请在蓝图中添加 Mod面板 节点", icon='INFO')

        layout.prop(context.scene.global_properties, "open_mod_folder_after_generate_mod",text="生成Mod后打开Mod所在文件夹")

        layout.prop(context.scene.global_properties, "use_specific_generate_mod_folder_path")

        if GlobalProterties.use_specific_generate_mod_folder_path():
            box = layout.box()
            box.label(text="当前生成Mod位置文件夹:")
            box.prop(context.scene.global_properties, "generate_mod_folder_path", text="")

        row = layout.row()
        row.prop(self, "show_vertex_deduplication_panel", 
                 icon='TRIA_DOWN' if self.show_vertex_deduplication_panel else 'TRIA_RIGHT',
                 icon_only=True, emboss=False)
        row.label(text="顶点去重精度控制")

        if self.show_vertex_deduplication_panel:
            box = layout.box()
            col = box.column()
            col.label(text="参与去重的数据类型:")
            col.prop(context.scene.global_properties, "deduplicate_POSITION")
            col.prop(context.scene.global_properties, "deduplicate_NORMAL")
            col.prop(context.scene.global_properties, "deduplicate_TANGENT")
            col.prop(context.scene.global_properties, "deduplicate_BINORMAL")
            col.prop(context.scene.global_properties, "deduplicate_TEXCOORD")
            col.prop(context.scene.global_properties, "deduplicate_COLOR")
            col.prop(context.scene.global_properties, "deduplicate_BLENDWEIGHT")
            col.prop(context.scene.global_properties, "deduplicate_BLENDINDICES")

    def update(self):
        if self.inputs and self.inputs[-1].is_linked:
            self.inputs.new('SSMTSocketObject', f"Group {len(self.inputs) + 1}")
        
        if len(self.inputs) > 1 and not self.inputs[-1].is_linked and not self.inputs[-2].is_linked:
             self.inputs.remove(self.inputs[-1])


class SSMT_OT_View_Group_Objects(bpy.types.Operator):
    '''递归解析当前组下面所有的物体并在当前3D视图中展示，点击切换局部视图，注意组节点最好不要包含按键切换，否则会同时展示所有切换分支内容'''
    bl_idname = "ssmt.view_group_objects"
    bl_label = "View Group Objects"
    
    node_name: bpy.props.StringProperty()

    @staticmethod
    def _node_visit_key(node):
        tree_name = node.id_data.name if hasattr(node, "id_data") and node.id_data else ""
        node_name = getattr(node, "name", "")
        return f"{tree_name}::{node_name}"

    @staticmethod
    def _append_object_by_name(objects_to_show, obj_name):
        obj_name = str(obj_name or "").strip()
        if not obj_name:
            return
        obj = bpy.data.objects.get(obj_name)
        if obj:
            objects_to_show.add(obj)

    def _collect_group_preview_objects(self, current_node, objects_to_show, visited_nodes, visited_blueprints):
        node_key = self._node_visit_key(current_node)
        if node_key in visited_nodes:
            return
        visited_nodes.add(node_key)

        node_type = getattr(current_node, "bl_idname", "")
        if node_type == 'SSMTNode_Object_Info':
            self._append_object_by_name(objects_to_show, getattr(current_node, "object_name", ""))
        elif node_type == 'SSMTNode_MultiFile_Export':
            for item in getattr(current_node, "object_list", []):
                self._append_object_by_name(objects_to_show, getattr(item, "object_name", ""))
        elif node_type == 'SSMTNode_Blueprint_Nest':
            nested_tree_name = str(getattr(current_node, "blueprint_name", "") or "").strip()
            if nested_tree_name and nested_tree_name != 'NONE' and nested_tree_name not in visited_blueprints:
                nested_tree = bpy.data.node_groups.get(nested_tree_name)
                if nested_tree and getattr(nested_tree, "bl_idname", "") == 'SSMTBlueprintTreeType':
                    visited_blueprints.add(nested_tree_name)
                    for nested_node in nested_tree.nodes:
                        if getattr(nested_node, "bl_idname", "") == 'SSMTNode_Result_Output':
                            self._collect_group_preview_objects(
                                nested_node,
                                objects_to_show,
                                visited_nodes,
                                visited_blueprints,
                            )

        if hasattr(current_node, "inputs"):
            for inp in current_node.inputs:
                if inp.is_linked:
                    for link in inp.links:
                        self._collect_group_preview_objects(
                            link.from_node,
                            objects_to_show,
                            visited_nodes,
                            visited_blueprints,
                        )

    def execute(self, context):
        tree = getattr(context.space_data, "edit_tree", None) or getattr(context.space_data, "node_tree", None)
        if not tree:
             return {'CANCELLED'}
        node = tree.nodes.get(self.node_name)
        if not node:
             return {'CANCELLED'}

        view_3d_area = None
        view_3d_window = None
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    view_3d_area = area
                    view_3d_window = window
                    break
            if view_3d_area:
                break
        
        if not view_3d_area:
            self.report({'WARNING'}, "No 3D View found")
            return {'CANCELLED'}

        in_local_view = False
        for space in view_3d_area.spaces:
            if space.type == 'VIEW_3D' and space.local_view:
                in_local_view = True
                break
        
        if in_local_view:
            try:
                with context.temp_override(window=view_3d_window, area=view_3d_area):
                    bpy.ops.view3d.localview()
                self.report({'INFO'}, "Exited local view")
            except Exception as e:
                self.report({'WARNING'}, f"Could not exit local view: {e}")
            return {'FINISHED'}

        objects_to_show = set()
        checked_nodes = set()
        visited_blueprints = set()
        self._collect_group_preview_objects(node, objects_to_show, checked_nodes, visited_blueprints)

        view_layer_object_names = {
            obj.name
            for obj in getattr(context.view_layer, "objects", []) or []
        }
        objects_to_show = {
            obj
            for obj in objects_to_show
            if obj is not None and getattr(obj, "name", "") in view_layer_object_names
        }
        
        if not objects_to_show:
            self.report({'WARNING'}, "No selectable objects found in this group for the current View Layer")
            return {'CANCELLED'}

        def deselect_all_safe():
            for o in bpy.context.selected_objects:
                o.select_set(False)

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        deselect_all_safe()
        for obj in objects_to_show:
            obj.select_set(True)

        region = next((r for r in view_3d_area.regions if r.type == 'WINDOW'), None)
        if region:
            try:
                with context.temp_override(window=view_3d_window, area=view_3d_area, region=region):
                    bpy.ops.view3d.localview()
                    bpy.ops.view3d.view_axis(type='FRONT')
                    bpy.ops.view3d.view_selected()
                    if view_3d_area.spaces.active:
                        view_3d_area.spaces.active.shading.type = 'SOLID'
            except Exception as e:
                print(f"View setup warning: {e}")

        self.report({'INFO'}, f"Showing {len(objects_to_show)} objects in local view")
        return {'FINISHED'}


classes = (
    SSMT_OT_RefreshNodeObjectIDs,
    SSMT_OT_SelectNodeObject,
    SSMT_OT_StartPickObject,
    SSMT_OT_PickObjectModal,
    SSMT_OT_SelectGenerateModFolder,
    SSMT_OT_View_Group_Objects,
    SSMTNode_Object_Info,
    SSMTNode_Object_Group,
    SSMTNode_Result_Output,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_HT_header.append(draw_view3d_header)


def unregister():
    bpy.types.VIEW3D_HT_header.remove(draw_view3d_header)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
