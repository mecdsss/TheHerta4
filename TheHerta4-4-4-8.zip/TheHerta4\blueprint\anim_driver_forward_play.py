import bpy
from bpy.props import FloatProperty, StringProperty, BoolProperty, IntProperty, CollectionProperty

from .anim_driver_base import SSMTNode_AnimDriver_Base, DrivenVariableItem


class SSMTNode_AnimDriver_ForwardPlay(SSMTNode_AnimDriver_Base):
    bl_idname = 'SSMTNode_AnimDriver_ForwardPlay'
    bl_label = '索引播放'
    bl_icon = 'PLAY'

    frame_start: FloatProperty(
        name="起始数值",
        description="动画播放的起始数值",
        default=0.0,
        precision=3,
    )

    frame_end: FloatProperty(
        name="结束数值",
        description="动画播放的结束数值",
        default=14.0,
        precision=3,
    )

    driven_variable: StringProperty(
        name="驱动变量(旧)",
        description="旧版驱动变量（已迁移到列表）",
        default="",
        options={'HIDDEN'},
    )

    driven_variable_list: CollectionProperty(
        type=DrivenVariableItem,
        name="驱动变量列表",
    )

    driven_variable_list_active: IntProperty(
        name="当前驱动变量",
        default=0,
    )

    play_total_duration: FloatProperty(
        name="播放总时长",
        description="动画播放的总时长（秒），系统自动计算播放间隔",
        default=1.0,
        min=0.001,
        max=999.0,
        step=1.0,
        precision=3,
    )

    default_paused: BoolProperty(
        name="默认暂停",
        description="节点默认处于暂停状态",
        default=True,
    )

    custom_paused_var: StringProperty(
        name="暂停变量",
        description="自定义暂停状态变量名（留空自动分配 $animation_paused{N}）",
        default="",
    )

    reverse_playback: BoolProperty(
        name="反向播放",
        description="反向播放，变量从结束帧递减到起始帧",
        default=False,
    )

    use_float_interval: BoolProperty(
        name="浮点计算",
        description="开启时播放间隔按浮点计算，关闭时取整为整数",
        default=True,
    )

    loop_playback: BoolProperty(
        name="循环播放",
        description="播放到最后一帧后自动从头开始循环（中间节点强制禁用）",
        default=True,
    )

    def _get_driven_vars(self):
        """获取所有驱动变量名列表（自动补$前缀）"""
        vars_list = []
        for item in self.driven_variable_list:
            var = item.variable_name.strip()
            if var:
                if not var.startswith('$'):
                    var = f"${var}"
                vars_list.append(var)
        # 向后兼容：如果列表为空但旧字段有值
        if not vars_list:
            old_var = self.driven_variable.strip()
            if old_var:
                if not old_var.startswith('$'):
                    old_var = f"${old_var}"
                vars_list.append(old_var)
        if not vars_list:
            vars_list.append("$driven_var")
        return vars_list

    def init(self, context):
        self.inputs.new('SSMTSocketAnimDriver', "链输入")
        self.inputs.new('SSMTSocketAnimDriver', "时间输入")
        self.inputs.new('SSMTSocketAnimDriver', "驱动输入")
        self.outputs.new('SSMTSocketAnimDriver', "链输出")
        self.outputs.new('SSMTSocketAnimDriver', "时间输出")
        self.width = 300
        self._assign_next_available_index()
        self.custom_paused_var = f"$animation_paused{self.auto_index}"

    def copy(self, node):
        self._assign_next_available_index()
        self.custom_paused_var = f"$animation_paused{self.auto_index}"

    def _compute_play_interval(self):
        runtime = self._find_runtime_node()
        fps = runtime.fps if runtime else 30
        playback_rate = runtime.playback_rate if runtime else 1
        total_steps = abs(self.frame_end - self.frame_start)
        total_frames = total_steps + 1
        if self.play_total_duration <= 0 or total_steps <= 0:
            return 1.0, total_frames, fps, playback_rate
        effective_ticks = self.play_total_duration * fps / playback_rate
        if effective_ticks <= 0:
            return 1.0, total_frames, fps, playback_rate
        interval = total_steps / effective_ticks
        return interval, total_frames, fps, playback_rate

    def draw_buttons(self, context, layout):
        safe_idx = self._read_safe_index()
        box = layout.box()
        row = box.row(align=True)
        row.label(text=f"索引: {safe_idx}", icon='LINENUMBERS_ON')
        row.prop(self, "use_float_interval", text="浮点", icon='IPO_BEZIER')
        box.prop(self, "frame_start")
        box.prop(self, "frame_end")

        # 驱动变量列表
        row = box.row(align=True)
        row.label(text="驱动变量:", icon='VIEWZOOM')
        op = row.operator("ssmt.driven_variable_add", text="", icon='ADD')
        op.node_name = self.name
        op = row.operator("ssmt.driven_variable_remove", text="", icon='REMOVE')
        op.node_name = self.name

        if self.driven_variable_list:
            box.template_list(
                "SSMT_UL_DRIVEN_VARIABLES", "",
                self, "driven_variable_list",
                self, "driven_variable_list_active",
                rows=max(2, min(len(self.driven_variable_list), 6)),
            )
        else:
            box.label(text="点击 + 添加驱动变量", icon='INFO')

        interval, total_frames, fps, playback_rate = self._compute_play_interval()

        box.prop(self, "play_total_duration")
        info_col = box.column(align=True)
        info_col.label(text=f"总帧数: {total_frames}")
        if self.use_float_interval:
            info_col.label(text=f"播放间隔: {interval:.4f}")
        else:
            info_col.label(text=f"播放间隔: {interval:.4f} (取整为 {max(1, int(interval))})")
        info_col.label(text=f"帧率: {fps} | 速率: {playback_rate}")

        box.separator()
        row = box.row(align=True)
        row.prop(self, "default_paused", text="默认暂停")
        if self.custom_paused_var.strip():
            row.prop(self, "custom_paused_var", text="")
        else:
            row.label(text=f"$animation_paused{safe_idx}")

        row = box.row(align=True)
        row.prop(self, "reverse_playback", text="反向", icon='ARROW_LEFTRIGHT')

        if self._get_next_node_in_chain() is not None:
            row.label(text="循环已禁用（下游有节点）", icon='FILE_REFRESH')
        else:
            row.prop(self, "loop_playback", text="循环", icon='FILE_REFRESH')

        box.separator()
        box.label(text="输入说明:", icon='INFO')
        if self.inputs.get("时间输入") and self.inputs["时间输入"].is_linked:
            box.label(text="  [时间输入] 已连接", icon='TIME')
        else:
            box.label(text="  [时间输入] 未连接", icon='ERROR')
        if self.inputs.get("驱动输入") and self.inputs["驱动输入"].is_linked:
            box.label(text="  [驱动输入] 已连接", icon='KEYFRAME')
        else:
            box.label(text="  [驱动输入] 未连接", icon='SNAP_FACE')
        if self.outputs.get("时间输出") and self.outputs["时间输出"].is_linked:
            box.label(text="  [时间输出] 已连接（传递到下一节点）", icon='FORWARD')

    def generate_ini_segment(self, connected_nodes=None) -> str:
        idx = self._read_safe_index()
        driven_vars = self._get_driven_vars()
        primary_var = driven_vars[0]

        runtime = self._find_runtime_node()
        playback_rate = runtime.playback_rate if runtime else 1

        paused_state = 0 if self.default_paused else 1
        paused_var = self.custom_paused_var.strip()
        if not paused_var:
            paused_var = f"$animation_paused{idx}"
        elif not paused_var.startswith('$'):
            paused_var = f"${paused_var}"

        interval, _, _, _ = self._compute_play_interval()
        interval_str = f"{interval:.4f}" if self.use_float_interval else str(max(1, int(interval)))

        has_next_in_chain = self._get_next_node_in_chain() is not None
        can_loop = not has_next_in_chain and self.loop_playback

        if self.reverse_playback:
            check_bound = f"$frameStart{idx}"
            check_op = ">"
            op = "-"
            reset_target = f"$frameEnd{idx}"
        else:
            check_bound = f"$frameEnd{idx}"
            check_op = "<"
            op = "+"
            reset_target = f"$frameStart{idx}"

        lines = [
            "[Constants]",
            f"global $speed_auto{idx} = {playback_rate}",
            "; 切换速度（由运行时间的播放速率控制）",
            f"global $frameStart{idx} = {self.frame_start}",
            "; 起始帧",
            f"global $frameEnd{idx} = {self.frame_end}",
            "; 结束帧",
            f"global {paused_var} = {paused_state}",
            "; 默认暂停状态",
            "[Present]",
            f"if {paused_var} == 1",
            f"    if $swapvar % $speed_auto{idx} == 0",
            f"        if {primary_var} {check_op} {check_bound}",
        ]

        # 所有驱动变量递增
        for var in driven_vars:
            lines.append(f"            {var} = {var} {op} {interval_str}")

        clamp_op = ">" if not self.reverse_playback else "<"
        clamp_target = f"$frameEnd{idx}" if not self.reverse_playback else f"$frameStart{idx}"
        lines.append(f"            if {primary_var} {clamp_op} {clamp_target}")
        for var in driven_vars:
            lines.append(f"                {var} = {clamp_target}")
        lines.append("            endif")

        lines.append("        else")

        if can_loop:
            for var in driven_vars:
                lines.append(f"            {var} = {reset_target}")
            lines.extend([
                "        endif",
                "    endif",
                "endif",
            ])
        elif has_next_in_chain:
            next_paused = self._get_next_paused_var()
            if next_paused:
                lines.append(f"            {paused_var} = 0")
                lines.append(f"            {next_paused} = 1")
                for var in driven_vars:
                    lines.append(f"            {var} = {reset_target}")
                lines.extend([
                    "        endif",
                    "    endif",
                    "endif",
                ])
            else:
                lines.append(f"            {paused_var} = 0")
                for var in driven_vars:
                    lines.append(f"            {var} = {reset_target}")
                lines.extend([
                    "        endif",
                    "    endif",
                    "endif",
                ])
        else:
            lines.append(f"            {paused_var} = 0")
            for var in driven_vars:
                lines.append(f"            {var} = {reset_target}")
            lines.extend([
                "        endif",
                "    endif",
                "endif",
            ])

        return "\n".join(lines)


_load_handler_registered = False


@bpy.app.handlers.persistent
def _forward_play_load_handler(dummy):
    for tree in bpy.data.node_groups:
        if tree.bl_idname != 'SSMTBlueprintTreeType':
            continue
        for node in tree.nodes:
            if node.bl_idname == 'SSMTNode_AnimDriver_ForwardPlay':
                try:
                    SSMTNode_AnimDriver_Base._migrate_play_sockets(node)
                    if not node.custom_paused_var:
                        node.custom_paused_var = f"$animation_paused{node.auto_index}"
                    # 迁移旧 driven_variable 到 driven_variable_list
                    old_var = node.driven_variable.strip()
                    if old_var and len(node.driven_variable_list) == 0:
                        item = node.driven_variable_list.add()
                        item.variable_name = old_var
                        node.driven_variable = ""
                except Exception:
                    pass


classes = (
    SSMTNode_AnimDriver_ForwardPlay,
)


def register():
    global _load_handler_registered
    for cls in classes:
        bpy.utils.register_class(cls)
    if not _load_handler_registered:
        bpy.app.handlers.load_post.append(_forward_play_load_handler)
        _load_handler_registered = True


def unregister():
    global _load_handler_registered
    if _load_handler_registered:
        bpy.app.handlers.load_post.remove(_forward_play_load_handler)
        _load_handler_registered = False
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
